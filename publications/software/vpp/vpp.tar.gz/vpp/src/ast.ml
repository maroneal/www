open Lexing

(* ------------ Gate Count AST *)

type gcexp =
  | GcLit of int
  | GcVar of string
  | GcMod of string * gcexp list
  | GcOp of string * gcexp list
  | GcCond of gcexp * gcexp * gcexp
  | GcSum of string * gcexp * gcexp * gcexp

(*------------- Constraints AST *)

type rel_op = 
    LT
  | GT
  | LTE
  | GTE
  | EQ
  | NEQ

type bin_op = 
    PLUS
  | MINUS
  | TIMES
  | DIV
  | MOD

type expression =
    Variable of string  
  | Literal of int
  | Op of expression * bin_op * expression
  | Abs of expression
  | Power of expression
  | Min of expression * expression
  | Max of expression * expression
  | Shiftr of expression * expression
  | Shiftl of expression * expression

type constrnt =
  | Bool of bool 
  | Relation of expression * rel_op * expression
  | Conj of constrnt * constrnt
  | Disj of constrnt * constrnt
  | Neg of constrnt

(*----------- dir and vtype AST  --------------*)

type dir = IN | OUT | INOUT | NODIR

and btype = 
  | WIRE 
  | REG   

and vtype = 
  | INT
  | BTYPE of btype 
  | TVAR of string
  | VECT of btype * ((expression * expression) option) * expression 
  | ARR of vtype * ((expression * expression) option) * expression 
(* Where expression is in Constraint BNF
 * An ARR has a type an optional lower and upper bounds
 * These bounds are none in the case of module types 
 * and a width *)

(*-------- VPP AST --------------------------------*)

type src_loc = { loc_start: position; loc_end: position; loc_ghost: bool}
and t = src_loc option

(* Abstract syntax tree for restricted subset of Verilog *)
(* Verilog BNF: http://www.verilog.com/VerilogBNF.html *)

(* Section 1: Source Text *)
(* Source_text is composed of a list of assumed modules with given types and a list of defined modules *)
type source_text =
    Source_text of t * (mod_nm_typ list) * (mod_v list)

(* Each assumed module has:
 *  a name, 
 *  a list of modular parameters each having a name and type
 *  a list of parameters each having a name and a default value (or expression), and an optional constraint
 *  a list of ports each having a direction, type and a name (needed for named instanciations)
 *  an expression representing a gate count estimation 
 *) 
and mod_nm_typ    =
    ModNameType of t * name_of_module * 
      (name_of_module * mod_typ) list * 
      (name_of_parameter * exp * exp option) list * 
      (dir * vtype * name_of_port) list * exp option

and mod_typ = 
    ModType of t * mod_typ list * name_of_parameter list * (dir * vtype * name_of_port) list    

(* only used by the parser to construct the right types for
 * ports of assumed modules *)
and width = 
    No_width
  | Width of exp * width

(* Each defined module has:
 * a name,
 * a list of ports (can be empty)
 * a list of module items (including declarations, assignments, gate instantiations)
 *) 
and mod_v  = 
    Module of t * name_of_module * (name_of_port list) * module_item list

and module_item	=
    (* Parameter names and default values *)
    Parameter_declaration of t * (param_assignment list) 
      (* Ports, signals, and local variable declarations. Some declaration 
       * have range and array_bounds.*)
  | Mod_param_declaration of t * name_of_module * mod_typ 
  | Input_declaration of t * range * (name_of_variable list) * array_bounds 
  | Output_declaration of t * range * (name_of_variable list) * array_bounds 
  | Inout_declaration of t * range * (name_of_variable list) * array_bounds 
  | Net_declaration of t * net_type * range * delay * (name_of_variable list) * array_bounds 
  | Var_declaration of t * string * (name_of_variable list) * array_bounds
  | Reg_declaration of t * range * (name_of_variable list) * array_bounds 
  | Int_declaration of t * (name_of_variable list) * array_bounds 
  | Genvar_declaration of t * (name_of_variable list) 
      (* Structrural Constructs *)
  | Gate_declaration of t * gate_type * delay * (gate_instance list)
  | Instantiation of t * name_of_module * mod_param_assigns * param_assign * module_instance * ((string * vtype) list option ref) 
      (* list of type substitutions after unification *)
  | P_if_stmt of t * exp * (module_item list)
  | P_if_else_stmt of t * exp * (module_item list) * (module_item list)
  | P_for_stmt of t * (assignment list) * exp * (assignment list) * (module_item list)
  | P_case_stmt of t * exp * (p_case_item list)
      (* Behavioral Constructs. Unless restriced, assignment statements 
       * can include behavioral constructs. *)
  | Continuous_assign of t * delay * (assignment list)
  | Always_statement of t * statement

and param_assignment = t * identifier * exp * exp option (*The exp option is the optional constraint on the parameter*)

and range = 
    No_range 
  | Range of t * exp * exp

and array_bounds = 
    No_bounds 
  | Bounds of t * exp * exp * array_bounds

and net_type = t * string

and delay =
    No_delay 
  | Num_delay of t * number
  | Ident_delay of t * identifier

(* Primitive Instances *)

and gate_type = t * string

and gate_instance = t * name_of_gate_instance * (exp list)

and name_of_gate_instance =
    No_gatename 
  | Gatename of t * identi_nodot * range

(* Module Instantiations *)

and param_assign = exp list

and mod_param_assigns = mod_param_assign list

and mod_param_assign = ModParamAssign of name_of_module * mod_param_assigns * param_assign

and module_instance = t * name_of_module_instance * list_of_module_connections 

and list_of_module_connections = 
    Mod_port_conn of (exp option) list
  | Named_port_conn of (identi_nodot * exp option) list

(* Generative Constructs *) 

and p_case_item =
    P_case_item of t * (exp list) * (module_item list)
  | P_case_default of t * module_item list

(* Behavioral Statements *)

and assignment = t * lvalue * exp

and statement =
    Blocking_assignment of t * blocking_assignment
  | Non_blocking_assignment of t * non_blocking_assignment
  | If_stmt of t * exp * statement option
  | If_else_stmt of t * exp * statement option * statement option
  | Delay_or_event_control of t * delay_or_event_control * statement option
  | Sequential_block of t * statement list
  | System_task_enable of t * system_task_enable
  | Assign_stmt of t * assignment
  | For_stmt of t * (assignment list) * exp * (assignment list) * statement option
  | Case_stmt of t * exp * case_item list

and blocking_assignment =
    B_assign of t * lvalue * exp
  | Control_B_assign of t * lvalue * delay_or_event_control * exp

and non_blocking_assignment =
    Nb_assign of t * lvalue * exp
  | Control_Nb_assign of t * lvalue * delay_or_event_control * exp

and delay_or_event_control =
    Delay_control of t * delay_control
  | Event_control of t * event_control

and delay_control =
    Num_dc of t * number
  | Ident_dc of t * identifier
  | Mintypmax_dc of t * mintypmax_exp

and event_control =
    Id_ec of t * identifier
  | Event_exp of t * event_exp

and event_exp =
    Exp_event of t * exp
  | Posedge of t * scalar_event_exp
  | Negedge of t * scalar_event_exp
  | Or_event_exp of t * event_exp * event_exp

and scalar_event_exp = t * exp

and system_task_enable =
    Sys_task of t * name_of_system_task
  | Sys_task_e of t * name_of_system_task * exp list

and case_item =
    Case_item of t * exp list * statement option
  | Case_default of t * statement option

(* Expressions *)

and lvalue =
    Ident_lval of t * identifier * select
  | Concat_lv of t * exp list

and mintypmax_exp =
    Exp_mtm of t * exp
  | Mintypmax of t * exp * exp * exp

and exp =
    Primary of t * primary
  | Unary_exp of t * string * primary
  | Bin_exp of t * exp * string * exp
  | Cond_exp of t * exp * exp * exp
  | String_exp of t * string

and primary =
    Num_primary of t * number
  | Id_primary of t * identifier * select
  | Concat of t * exp list
  | Mult_concat of t * exp * exp list
  | Mintypmax_primary of t * mintypmax_exp

and select = 
    No_select
  | Bit_select of t * exp * select
  | Part_select of t * exp * exp * select

(* Names *)

and name_of_module = t * identi_nodot

and name_of_module_instance = t * identi_nodot

and name_of_parameter = t * identifier

and name_of_port = t * identi_nodot

and name_of_variable = t * identi_nodot

and name_of_system_task = t * string

(* number and identifier are given meaningful definitions in the lexer, 
 * but are then passed to the parser as strings *)

and number = t * string

and identifier = t * string * bool ref 

and identi_nodot = t * string * bool ref
;;
	
