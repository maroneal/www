(* Main file for VPP *)

let _ = 
  let filename = ref None in
  let outputfilename = ref None in
  let tc_only = ref false in
(*let ex_only = ref false in 
  let check_constraints = ref true in 
  let print_constraints = ref false in*)
  let print_param_gate_counts = ref false in
  let print_gate_counts = ref false in
  let print_timings = ref false in
(*let allow_unchecked_behavioral = ref false in*)

  let _ = Arg.parse 
    [
      ("-tc",Arg.Unit(fun () -> tc_only := true),"type check only");
     (*("-pp",Arg.Unit(fun () -> ex_only := true),"preprocess only");
     ("-nocc",Arg.Unit(fun () -> check_constraints := false),"do not check consistency constraints (not supported yet)");
     ("-pc",Arg.Unit(fun () -> print_constraints := true),"print consistency constraints (only works when -nocc is off)");*)
      ("-ppg",Arg.Unit(fun () -> print_param_gate_counts := true),"print parametric gate counts");
     (*("-pg",Arg.Unit(fun () -> print_gate_counts := true),"print numeric gate counts");*)
      ("-time",Arg.Unit(fun () -> print_timings := true),"print timings");
     (*("-b",Arg.Unit(fun () -> allow_unchecked_behavioral := true),"allow (unchecked) behavioral Verilog (not supported yet)");*)
     ("-o", Arg.String(fun s -> outputfilename := Some s),"output filename for expanded Verilog (only works when -tc is off)")]
    (fun s -> filename := Some s) "Verilog Preprocessor ver 1.0"
  in
    match !filename with
	None ->
	  print_string "Filename must be specified.\n"
      | Some fn -> 
	  try
	    let print_output p_exp = 
	      (match !outputfilename with
		 | None -> let _ = 
		     if ((*!print_constraints ||*) !print_param_gate_counts || !print_gate_counts || !print_timings ) then 
		       let _ = print_string "Elaborated description:\n" in
			 print_string "-----------------------\n\n" 
		     else () in
		     Printer.print_source_text Format.std_formatter p_exp 
		 | Some ofn -> 
		     Printer.print_source_text (Format.formatter_of_out_channel (open_out ofn)) p_exp)
	    in 
	    let print_timing pt tct yt tat ext =
	      let _ = print_string ("Timings:\n") in 
	      let _ = print_string ("--------\n") in 
	      let _ = print_string ("Parse Time: " ^ (string_of_float pt) ^ " s\n") in
	      let _ = print_string ("Type Checking Time (excluding constraint checking): " ^ (string_of_float (tct-.yt)) ^ " s\n") in
	      let _ = print_string ("Constraint Checking: " ^ (string_of_float yt) ^ " s\n") in
	      let _ = print_string ("Termination Analysis: " ^ (string_of_float tat) ^ " s\n") in
	      let _ = print_string ("Preprocessing Time: " ^ (string_of_float ext) ^ " s\n\n") in 
		()
	    in  
	    let (p,parse_time) = Util.time_fun (fun () -> ParseLib.parse_file fn) in
	      (*if !ex_only then
		let p_exp = Interp.ex_program p in
		  print_output p_exp
	      else*)
	    let (gr,tc_time) = Util.time_fun (fun () -> Interp.tc_program p !tc_only) in
	    let (_,ter_time) = Util.time_fun (fun () -> Interp.analyze_termination gr) in
	      (*let _ = if !print_constraints then (print_string (Printer.print_prog_constrnts 80 (!Interp.conlst)); print_newline()) else () in*)
	    let _ = if !print_param_gate_counts then (print_string (Printer.print_prog_gcexps 80 (!Interp.gclst)); print_newline()) else () in
	    (*let _ = if !print_gate_counts then print_string ("Pre-elaboration gate count = " ^ string_of_int gc1) else () in*)
	    let _ = 
	      if !tc_only then if !print_timings then print_timing parse_time tc_time !Interp.yices_time ter_time 0.0 else ()
	      else (let (p_exp,ex_time) = Util.time_fun (fun () -> Interp.ex_program p) in
		    let _ = if !print_timings then print_timing parse_time tc_time !Interp.yices_time ter_time ex_time else () in
		    (*let _ =  
		      if !print_gate_counts then 
			let gc2 = Interp.tc_program p_exp in 
			  print_string (", Post-elaboration (actual) gate count = " ^ string_of_int gc2 ^"\n\n") 
		      else () in*) 
		      print_output p_exp) in
	      print_newline() 
	  with
	      ParseError.Error(ParseError.Unterminated_comment pos) -> 
		print_string ("Lexing error: Unterminated comment at " ^ 
				(ParseError.string_of_position pos) ^ "\n")
	    | ParseError.Error(ParseError.Closing_noncomment pos) ->
		print_string ("Lexing error: Unopened comment at " ^ 
				(ParseError.string_of_position pos) ^ "\n")
	    | ParseError.Error(ParseError.Unclosed(open_pos,open_mark,close_pos,close_mark)) ->
		print_string
		  ("Syntax error: '" ^ close_mark ^ "' expected. '" ^
		     open_mark ^ "'at " ^ (ParseError.string_of_range open_pos) ^
		     " might be unmatched\n");
	    | ParseError.Error(ParseError.Other r) ->
		print_string 
		  ("Syntax error at " ^ (ParseError.string_of_range r) ^ "\n")
	    | ParseError.FileNotFound name ->
		print_string ("Read Error: The file '" ^ name ^ "' could not be read!\n")
	    | Interp.Div_by_zero -> 
		print_string "Interpreter Error: Division by zero exception\n"
	    | Interp.TypeErr (msg, loc) ->
		print_string ("Type error at " ^ Printer.loc_to_string loc ^ "\n  " ^ msg ^ "\n") 
	    | Interp.TermErr (msg) ->
		print_string ("Termination error\n  " ^ msg ^ "\n") 
	    | Interp.GcErr (msg,loc) ->
		print_string ("Gate count error at " ^ Printer.loc_to_string loc ^ "\n  " ^ msg ^ "\n") 
	    | Interp.ConErr (msg, loc) ->
		print_string ("Constraint generation error at " ^ Printer.loc_to_string loc ^ "\n  " ^ msg ^ "\n") 
	    | Interp.SubError (msg, loc) -> 
		print_string ("Substitution error at " ^ Printer.loc_to_string loc ^ "\n  " ^ msg ^ "\n") 
	    | Interp.ExError (msg, loc) -> 
		print_string ("Unexepected: Elaboration error " ^ Printer.loc_to_string loc ^ "\n  " ^ msg ^ "\n") 
	    | Division_by_zero -> 
		print_string "Division by zero exception\n"
		  
(*in let (_,t) = Util.time_fun main in
  print_string ("Total User Time: " ^ (string_of_float t) ^ "s\n\n")*)
