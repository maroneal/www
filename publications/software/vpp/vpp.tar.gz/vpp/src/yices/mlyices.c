/* 
 * 
 * OCaml API Lite for Yices  
 * Revision: 1.0
 * Author: Cherif Salama (cherif@rice.edu) 
 * Last modified: Jan 26, 2009 
 * 
 */

#include "yicesl_c.h"
#include "caml/mlvalues.h"
#include "caml/alloc.h"
#include "caml/memory.h"
#include "caml/fail.h"
#include "caml/callback.h"
#include "caml/custom.h"
#include "caml/intext.h"

#define Ctxt_val(v) (*((yicesl_context *) Data_custom_val(v)))

struct custom_operations ctxt_ops = {
    "ctxt",
    custom_finalize_default,
    custom_compare_default,
    custom_hash_default,
    custom_serialize_default,
    custom_deserialize_default
};

value Val_ctxt(yicesl_context c) {
    CAMLparam0 ();
    CAMLlocal1 (v);
    v = alloc_custom( &ctxt_ops, sizeof(yicesl_context), 0, 1 );
    Ctxt_val(v) = c;
    CAMLreturn (v);
}  

CAMLprim value set_verbosity(value l)
{
  CAMLparam1 (l);
  yicesl_set_verbosity(Int_val(l));
  CAMLreturn (Val_unit);
}

CAMLprim value version(value unit)
{
  CAMLparam1 (unit);
  CAMLreturn(caml_copy_string(yicesl_version()));
}

CAMLprim value enable_type_checker(value flag)
{
  CAMLparam1 (flag);
  yicesl_enable_type_checker(Int_val(flag));
  CAMLreturn (Val_unit);
}

CAMLprim value enable_log_file (value file_name)
{
  CAMLparam1 (file_name);
  yicesl_enable_log_file(String_val(file_name));
  CAMLreturn (Val_unit);
}

CAMLprim value mk_context (value unit)
{
  CAMLparam1 (unit);
  CAMLreturn (Val_ctxt(yicesl_mk_context()));
}

CAMLprim value del_context(value ctx)
{
  CAMLparam1 (ctx);
  yicesl_del_context(Ctxt_val(ctx));
  CAMLreturn (Val_unit);
}

CAMLprim value yread(value ctx, value cmd)
{
  CAMLparam2 (ctx,cmd);
  CAMLreturn (Val_int(yicesl_read(Ctxt_val(ctx),String_val(cmd))));
}

CAMLprim value inconsistent(value ctx)
{
  CAMLparam1 (ctx);
  CAMLreturn (Val_int(yicesl_inconsistent(Ctxt_val(ctx))));
}

CAMLprim value get_last_error_message(value unit)
{
  CAMLparam1 (unit);
  CAMLreturn (caml_copy_string(yicesl_get_last_error_message()));
}

CAMLprim value set_output_file(value file_name)
{
  CAMLparam1 (file_name);
  yicesl_set_output_file(String_val(file_name));
  CAMLreturn (Val_unit);
}
