(* 
 * 
 * OCaml API Lite for Yices  
 * Revision: 1.0
 * Author: Cherif Salama (cherif@rice.edu) 
 * Last modified: Jan 26, 2009 
 * 
 *)

type yicesl_context

external yicesl_set_verbosity: int -> unit = "set_verbosity"
external yicesl_version: unit -> string = "version"
external yicesl_enable_type_checker: int -> unit = "enable_type_checker"
external yicesl_enable_log_file: string -> unit = "enable_log_file"

external yicesl_mk_context: unit -> yicesl_context = "mk_context"
external yicesl_del_context: yicesl_context -> unit = "del_context"
external yicesl_read: yicesl_context -> string -> int = "yread"
external yicesl_inconsistent: yicesl_context -> int = "inconsistent"

external yicesl_get_last_error_message: unit -> string = "get_last_error_message"
external yicesl_set_output_file: string -> unit = "set_output_file"
