open Ast;;
open Printf;;

(* Utility function that appends a list l1 to a list l2 without adding duplicates *)
let rec union l1 l2 = 
  match l1 with
  | [] -> l2
  | h::t -> if List.mem h l2 then union t l2 else h::union t l2

(* Utility functions that unions all lists in a list of lists l *)
and unionall l = 
  match l with
  | [] -> []
  | h::t -> union h (unionall t);;

(* function that transforms a list of constraints into 1 big conjunction *)
let rec make_conj cl = 
  match cl with
  | [] -> Bool(true)
  | [c] -> c
  | h::t -> Conj (h, make_conj t)

(* Utily functions *)

(* Converts a list of contraints to a disjunction of constraints *)
let rec make_disj cl =
  match cl with
  | [] -> Bool(false)
  | [c] -> c
  | h::t -> Disj(h,make_disj t)

(* Utility function that work on lists*)
(* val map2perm: ('a -> 'b ->'c) -> 'a list -> 'b list -> 'c list *)
(*map2perm f [a1; ... ; an] [b1; ... ; bn] is [f a1 b1; ... ; f a1 bn; ... ; f an b1; ... ; f an bn]*)
let rec map2perm f l1 l2 =
  match l1 with
  | [] -> []
  | h1::t1 -> 
      let l3 = List.map (f h1) l2 in
      let l4 = map2perm f t1 l2 in
      List.append l3 l4

(* Other functions *)
let rec mlist gen n acc = 
  if n = 0 then acc
  else 
    let nxt = (gen n) :: acc in
    mlist gen (n-1) nxt

let range start stop =
  if start = stop then [start]
  else if start < stop then 
    mlist (fun x -> x + start - 1) (stop - start + 1) []
  else
    mlist (fun x -> start - x + 1) (start - stop + 1) []

let setListMerge set1 set2 =
  List.fold_left (fun acc x -> 
    if List.exists (fun y -> x = y) set1 then acc
    else x :: acc) set1 set2

let extend f x y =
  (fun z ->
    if z = x then y else f z)

let rec split3 l = 
  match l with
    | [] -> ([],[],[])
    | ((x,y,z)::t) -> 
	let (xs,ys,zs) = split3 t in 
	  (x::xs,y::ys,z::zs)

let rec split4 l = 
  match l with
    | [] -> ([],[],[],[])
    | ((w,x,y,z)::t) -> 
	let (ws,xs,ys,zs) = split4 t in 
	  (w::ws,x::xs,y::ys,z::zs)

let rec split5 l = 
  match l with
    | [] -> ([],[],[],[],[])
    | ((w,v,x,y,z)::t) -> 
	let (ws,vs,xs,ys,zs) = split5 t in 
	  (w::ws,v::vs,x::xs,y::ys,z::zs)

let listsum l = 
  List.fold_left (+) 0 l 

let time_fun f =
  let ptimes1 = Unix.times () in
  let result = f () in
  let ptimes2 = Unix.times () in
  let diff = (ptimes2.Unix.tms_utime -. ptimes1.Unix.tms_utime) in
    (result,diff)

