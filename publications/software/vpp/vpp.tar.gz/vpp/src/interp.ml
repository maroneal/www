(* Some restrictions:
   - Modules must be presented in order
   - Last Module is automatically considered to be the main module
   - Direction of a port must be specified before its type (wire or reg)
   - We don't support net_declarations other than wire
*)

open Ast;;

exception Div_by_zero ;;
exception TypeErr of string * Ast.t;;
exception ConErr of string * Ast.t;;
exception GcErr of string * Ast.t;;
exception SubError of string * Ast.t;;
exception ExError of string * Ast.t;;
exception TermErr of string;;

(* module type:
   polymorphic type variable names list +
   module parameter list (including type of each) +
   parameter list (including default value expressions and constraints for each) +
   list of ports each with direction, type, and name (needed for connection by name) +
   gate count estimate (option) +
   flag indicating if this module is defined, assumed, or passed as a parameter

   Note that paramter default values are optional because module parameters do not have default
   values for parameters.
*)
type mtype = MODULE of string list * (string option * mtype) list * (string * exp option * exp option) list *  (dir *  vtype * string) list * gcexp option ref * modsource
and modsource = DEFINED | ASSUMED | PARAM


(* Instantiation Digraph for termination assignment *)
type graph = node list 
and node = Node of string * string list * edge list (*Module name, parameter names, instantiations*)
and edge = Edge of constrnt list * exp list * string (*list of guards (conjunction of guards), expressions 
							 used as parameter values at instantiation, name of instantiated module*)

(* ----------------- Global Mutable Variables ---------------------------------*)

(* List of assumed modules *)
let assumed_mods:string list ref = ref [];;

(* List of tuples associating a count to each instance name for 
 * for each module name (to generate new names for each 
 * instance) *) 
let modins_env:(string * string * int ref) list ref = ref [];;

(* List of gate count expressions. It is a list of pairs where for each pair:
   The first element is the module name
   The second element is a gate count expression *)
let gclst:(string * gcexp) list ref = ref [];;

(* list of port dimensions for each module. It is a list of pairs where for each pair:
   The first element is the module name
   The second element is a list of pairs (port name string and integer dimension) *)
let pdimlst:(string * (string * int) list) list ref = ref [];;

(* list of variable types for each module. Used for elaborations *)
let globalenv:(string * ((string * bool ref) * dir * vtype * int) list) list ref = ref [];;

let yices_time: float ref = ref 0.0;;

(* -------------------- Lookup and Helper functions ------------------------*)

(* returns a fresh number for each new module instance having a specific name *)	
let rec lookup_ins (mienv: (string*string*int ref) list) (mname:string) (minsname:string) :int =
  match mienv with
    | [] -> (modins_env := ((mname,minsname,ref 0)::!modins_env) ; 0)
    | (n,ni,c)::t ->
	if ((n=mname) & (ni=minsname)) 
	then let c2 = !c + 1 in (c:=c2 ; c2)
	else lookup_ins t mname minsname;;

(* Optionally returns the direction, type, and level of variable from 
 * the environment. If the variable is not found None is returned   
 *)
let rec lookup_env s env = 
  match env with
    | [] -> None
    | ((x,isSub1),d,ty,l)::t -> 
	let (y,isSub2) = s in
	  if x = y then ((isSub2:=!isSub1); Some(d,ty,l)) 
	  else lookup_env s t
	    
(* Optionally returns the type of a module from the module 
 * types environment if the required module is not found, 
 * None is returned
 *)
let rec lookup_menv (s:string) (menv:(string * mtype)list) : mtype option  = 
  match menv with
    | []-> None
    | (x,mty)::t -> 
	if (x=s) then Some mty 
	else lookup_menv s t

let listRemove a lst =
  let f x = (x<>a) in List.filter f lst

let is_in_dir dir = 
  match dir with
    | IN | INOUT -> true
    | _ -> false

let is_out_dir dir = 
  match dir with
    | OUT | INOUT -> true
    | _ -> false

let is_subset_dir dir1 dir2 = 
  match (dir1,dir2) with
    | (IN,IN) | (OUT,OUT) | (_,INOUT) -> true
    | _ -> false

let is_in_vtype (dir,_,_) = 
  is_in_dir dir

let is_out_vtype (dir,_,_) = 
  is_out_dir dir

let is_subset_dir_vtype (dir1,_,_) (dir2,_,_) = 
  is_subset_dir dir1 dir2

let int_of_number (_,n) =
  int_of_string n

(*************************************************************************)

(* evaluation of gate count expressions *)

let intdiv a b = 
  let r = a/b in 
    if a mod b = 0 then r else raise (GcErr("Result of division is not integral",None))

let bool_of_int n = 
  if (n=0) then false else true 

let int_of_bool b = 
  if b then 1 else 0

let rec gccontains x exp =
    match exp with
      | GcLit(_) -> false
      | GcVar(s) -> if s=x then true else false
      | GcMod(_,es) -> List.exists (gccontains x) es
      | GcOp(_,es) -> List.exists (gccontains x) es
      | GcCond(e1,e2,e3) -> (gccontains x e1) || (gccontains x e2) || (gccontains x e3)
      | GcSum(index,st,en,e) -> if index=x then false else ((gccontains x st) || (gccontains x en) || (gccontains x e))
 
let rec gccontainsdiv exp =
    match exp with
      | GcLit(_) -> false
      | GcVar(s) -> false
      | GcMod(_,es) -> List.exists gccontainsdiv es
      | GcOp("/",_) -> true
      | GcOp(_,es) -> List.exists gccontainsdiv es
      | GcCond(_,e2,e3) -> (gccontainsdiv e2) || (gccontainsdiv e3)
      | GcSum(index,st,en,e) -> (gccontainsdiv st) || (gccontainsdiv e)


(* simplification of gate count expressions *)
(* Way1: Simplify as much as possible during construction *)
let mkgcop op gcexplst = 
  match gcexplst with
    | [e] -> 	    
	begin match e with
	  | GcLit(v) ->
	      begin match op with
		| "+" -> e
		| "-" -> (GcLit(-v))
		| "!" -> (GcLit(int_of_bool (not (bool_of_int v))))
		| "floor" -> e
		| _ -> (GcOp(op,gcexplst))
	      end
	  | _ ->
	      begin match op with
		| "+" -> e
		| "floor" -> if gccontainsdiv e then (GcOp(op,gcexplst)) else e 
		|_ -> (GcOp(op,gcexplst))
	      end
	end	  
    | [e1;e2] ->
	begin match (e1,e2) with 
	  | (GcLit(v1), GcLit(v2)) ->
	      begin match op with 
		| "||" -> (GcLit (int_of_bool ((bool_of_int v1) || (bool_of_int v2))))
		| "&&" -> (GcLit (int_of_bool ((bool_of_int v1) && (bool_of_int v2))))
		| "==" -> (GcLit (int_of_bool (v1=v2)))
		| "!=" -> (GcLit (int_of_bool (v1<>v2)))
		| "===" -> (GcLit (int_of_bool (v1=v2)))
		| "!==" -> (GcLit (int_of_bool (v1<>v2)))
		| "<" -> (GcLit (int_of_bool (v1<v2)))
		| "<=" -> (GcLit (int_of_bool (v1<=v2)))
		| ">" -> (GcLit (int_of_bool (v1>v2)))
		| ">=" -> (GcLit (int_of_bool (v1>=v2)))
		| "<<" -> (GcLit (v1 lsl v2))
		| ">>" -> (GcLit (v1 lsr v2))
		| "<<<" -> (GcLit (v1 lsl v2))
		| ">>>" -> (GcLit (v1 asr v2))
		| "+" -> (GcLit (v1 + v2))
		| "-" -> (GcLit (v1 - v2))
		| "*" -> (GcLit (v1 * v2))
		| "/" -> (GcLit (intdiv v1 v2))
		| "%" -> (GcLit (v1 mod v2))
		| "**" -> (GcLit (int_of_float (float_of_int v1 ** float_of_int v2)))
		| _ -> (GcOp(op,gcexplst))		
	      end
	  | (GcLit(0),_) ->
	      begin match op with 
		| "||" -> e2
		| "&&" -> (GcLit 0)
		| "<<" -> (GcLit 0)
		| ">>" -> (GcLit 0)
		| "<<<" -> (GcLit 0)
		| ">>>" -> (GcLit 0)
		| "+" -> e2
		| "-" -> (GcOp("-",[e2]))
		| "*" -> (GcLit 0)
		| "/" -> (GcLit 0)
		| "%" -> (GcLit 0)
		| "**" -> (GcLit 0)
		| _ -> (GcOp(op,gcexplst))
	      end
	  | (_,GcLit(0)) ->
	      begin match op with
		| "||" -> e1
		| "&&" -> (GcLit 0)
		| "<<" -> e1
		| ">>" -> e1
		| "<<<" -> e1
		| ">>>" -> e1
		| "+" -> e1
		| "-" -> e1
		| "*" -> (GcLit 0)
		| "/" -> raise (GcErr("gcmkbinop / Div by zero",None))
		| "%" -> raise (GcErr("gcmkbinop % Div by zero",None))
		| "**" -> (GcLit 1)
		| _ -> (GcOp(op,gcexplst))
	      end
	  | (GcLit(1),_) when List.mem op ["||";"&&";"*";"**"]->
	      begin match op with
		| "||" -> (GcLit 1)
		| "&&" -> e2
		| "*" -> e2
		| "**" -> (GcLit 1)
		| _ -> (GcOp(op,gcexplst))
	      end
	  | (_,GcLit(1)) when List.mem op ["||";"&&";"*";"/";"%";"**"]->
	      begin match op with
		| "||" -> (GcLit 1)
		| "&&" -> e1
		| "*" -> e1
		| "/" -> e1
		| "%" -> e1
		| "**" -> e1
		| _ -> (GcOp(op,gcexplst))
	      end
	  | (GcOp("+",[e;GcLit(v1)]),GcLit(v2)) -> 
	      begin match op with 
		| "+" -> GcOp("+",[e;GcLit(v1+v2)]) 
		| "-" -> let v = v1-v2 in 
		    if v = 0 then e 
		    else if v<0 then GcOp("-",[e;GcLit(-v)]) 
		    else GcOp("+",[e;GcLit(v)]) 
		| _ -> (GcOp(op,gcexplst))		
	      end
	  | (GcOp("-",[e;GcLit(v1)]),GcLit(v2)) -> 
	      begin match op with 
		| "-" -> GcOp("-",[e;GcLit(v1+v2)]) 
		| "+" -> let v = v2-v1 in 
		    if v = 0 then e 
		    else if v<0 then GcOp("-",[e;GcLit(-v)]) 
		    else GcOp("+",[e;GcLit(v)]) 
		| _ -> (GcOp(op,gcexplst))		
	      end
	  | _ -> (GcOp(op,gcexplst))
	end	  
    | [e1;e2;e3] ->
	begin match (op,e1,e2,e3) with
	  | ("?",(GcLit v),_,_) when (bool_of_int v) -> e2
	  | ("?",(GcLit v),_,_) when (not (bool_of_int v)) -> e3
	  | ("?",_,e2,e3) when e2 = e3 -> e2
	  | _ -> (GcOp(op,gcexplst)) 
	end
    | _ -> (GcOp(op,gcexplst))

let mkgccond e1 e2 e3 = 
  match e1 with 
    | (GcLit v) when (bool_of_int v) -> e2
    | (GcLit v) when (not (bool_of_int v)) -> e3
    | _ -> if e2 = e3 then e2 else GcCond(e1,e2,e3) 

let rec mkgcsum index st en e =
  if gccontains index e then
    GcSum(index,st,en,e)
  else mkgcop "*" [mkgcop "floor" [(mkgcop "+" [mkgcop "-" [en;st];(GcLit 1)])];e]

(* substitution for gate count expressions *)
let rec gcsub_exp x e exp =
  let sub = gcsub_exp x e in
    match exp with
      | GcLit(_) -> exp
      | GcVar(s) -> if s=x then e else exp
      | GcMod(mn,es) -> GcMod(mn,List.map sub es)
      | GcOp(op,es) -> mkgcop op (List.map sub es)
      | GcCond(e1,e2,e3) -> GcCond(sub e1,sub e2,sub e3)
      | GcSum(index,st,en,e) -> GcSum(index,sub st,sub en,sub e)

let rec gcsumeval index st en e acc =  
  if st>en then acc 
  else gcsumeval index (mkgcop "+" [st;(GcLit 1)]) en e (mkgcop "+" [acc;(gcsub_exp index st e)]) 

let rec gceval exp =
  match exp with
    | GcLit(n) ->  n 
    | GcVar(_) -> raise (GcErr("Found variable while evaluating gate count",None)) 
    | GcMod(_,_) -> raise (GcErr("Found module with unknown gate count while evaluating gate count",None)) 
    | GcOp(op,[e]) -> 
	let v = gceval e in
	  begin match op with
	    | "+" -> v
	    | "-" -> -v
	    | "!" -> int_of_bool (not (bool_of_int v))
	    | "floor" -> v
	    | _ -> raise(GcErr("Unary op "^ op ^ "is not supported", None)) 
	  end
    | GcOp(op,[e1;e2]) ->
	let v1 = gceval e1 in
	let v2 = gceval e2 in
	  begin match op with
	    | "||" -> int_of_bool ((bool_of_int v1) || (bool_of_int v2))
	    | "&&" -> int_of_bool ((bool_of_int v1) && (bool_of_int v2))
	    | "==" -> int_of_bool (v1=v2)
	    | "!=" -> int_of_bool (v1<>v2)
	    | "===" -> int_of_bool (v1=v2)
	    | "!==" -> int_of_bool (v1<>v2)
	    | "<" -> int_of_bool (v1<v2)
	    | "<=" -> int_of_bool (v1<=v2)
	    | ">" -> int_of_bool (v1>v2)
	    | ">=" -> int_of_bool (v1>=v2)
	    | "<<" -> v1 lsl v2
	    | ">>" -> v1 lsr v2
	    | "<<<" -> v1 lsl v2
	    | ">>>" -> v1 asr v2
	    | "+" -> v1 + v2
	    | "-" -> v1 - v2
	    | "*" -> v1 * v2
	    | "/" -> intdiv v1 v2
	    | "%" -> v1 mod v2 
	    | "**" -> int_of_float (float_of_int v1 ** float_of_int v2)
	    | _ -> raise(GcErr("Binary op "^ op ^ "is not supported", None)) 
	  end
    | GcOp("?",[e1;e2;e3]) ->
	let v1 = gceval e1 in
	  if (bool_of_int v1) then gceval e2 else gceval e3 
    | GcOp(_,_) -> raise (GcErr("Only unary, binary, and conditional operators are supported",None))
    | GcCond(e1,e2,e3) -> 
	let v1 = gceval e1 in
	  if (bool_of_int v1) then gceval e2 else gceval e3 
    | GcSum(index,st,en,e) ->
	gceval (gcsumeval index st en e (GcLit 0))

let gclistsum (gcl:gcexp list) :gcexp = 
    List.fold_left (fun a b -> mkgcop "+" [a;b]) (GcLit 0) gcl


(***************************************************************************)
(* Convert Verilog Expressions to Gate Count expressions  ******************)

let rec vExpToGcExp exp =
  match exp with
      Primary(_, p) -> vPrimToGcExp p
    | Unary_exp(_,uop,p) -> mkgcop uop [(vPrimToGcExp p)] 
    | Bin_exp(_,e1,bop,e2) -> mkgcop bop [vExpToGcExp e1;vExpToGcExp e2] 
    | Cond_exp(_,e1,e2,e3) -> mkgccond (vExpToGcExp e1) (vExpToGcExp e2) (vExpToGcExp e3)
    | String_exp(loc,_) -> raise(GcErr("String expressions not supported", loc))

and vPrimToGcExp p = 
  match p with
      Num_primary(_, (_, num_string)) -> GcLit(int_of_string num_string)
    | Id_primary(_, (_,id,_), No_select) -> GcVar(id)
    | Id_primary(loc, _ , _) ->
	raise(GcErr("Signals are not supported",loc))
    | Concat(loc, _) ->
	raise(GcErr("Concat not supported",loc))
    | Mult_concat(loc,_,_) ->
	raise(GcErr("Multiple Concat not supported",loc))
    | Mintypmax_primary(loc,_) ->
	raise(GcErr("MinTypMax not supported",loc))

(***************************************************************************)
(* Convert Verilog Expressions to Constraints ******************************)

let rec vExpToConExp exp =
  match exp with
      Primary(_, p) -> vPrimToConExp p
    | Unary_exp(loc, uop,p) -> 
	(match uop with
	   | "+" -> vPrimToConExp p 
	   | "-" -> Op(Literal(0),MINUS,vPrimToConExp p)
	   | _ -> raise(ConErr("Unary Operator "^uop^" not supported", loc)))
    | Bin_exp(loc, e1,bop,e2) ->
	(match bop with
	   | "+" -> Op(vExpToConExp e1,PLUS,vExpToConExp e2)
	   | "-" -> Op(vExpToConExp e1,MINUS,vExpToConExp e2)
	   | "*" -> Op(vExpToConExp e1,TIMES,vExpToConExp e2)
	   | "/" -> Op(vExpToConExp e1,DIV,vExpToConExp e2)
	   | "%" -> Op(vExpToConExp e1,MOD,vExpToConExp e2)
	   | "<<" -> Shiftl(vExpToConExp e1,vExpToConExp e2)
	   | ">>" 
	   | ">>>" -> Shiftr(vExpToConExp e1,vExpToConExp e2)
	   | "**" -> 
	       (match e1 with
		    Primary(_,Num_primary(_,(_,n))) 
		      when (int_of_string n = 2) -> Power(vExpToConExp e2)
		  | _ -> raise(ConErr("Only powers with base 2 are supported", loc))) 	  
	   | _ -> 
	       raise(ConErr("Binary Operator "^bop^" not supported", loc)))
    | Cond_exp(loc, e,e1,e2) ->
	raise(ConErr("Conditional operator not supported", loc))      
    | String_exp(loc, s) ->
	raise(ConErr("String expressions not supported", loc))

and vPrimToConExp p = 
  match p with
      Num_primary(_, (_, num_string)) -> Literal(int_of_string num_string)
    | Id_primary(_, (_,id,_), No_select) -> Variable(id)
    | Id_primary(loc, _, _) ->
	raise(ConErr("Signals are not supported",loc))
    | Concat(loc, elist) ->
	raise(ConErr("Concat not supported",loc))
    | Mult_concat(loc, e,elist) ->
	raise(ConErr("Multiple Concat not supported",loc))
    | Mintypmax_primary(loc, mtme) ->
	raise(ConErr("MinTypMax not supported",loc))
;;

let rec vExpToCon exp =
  let boptable loc op =
     match op with 
	"<" -> LT
      | ">" -> GT
      | "<=" -> LTE
      | ">=" -> GTE
      | "==" -> EQ
      | "!=" -> NEQ
      | _ -> 
	  raise(ConErr("Binary Operator " ^ op ^ " not supported", loc))
  in
    (*Printer.print_exp Format.std_formatter exp;*)
    match exp with
	Primary(_, p) -> vPrimToCon p
      | Unary_exp(_, "+", p) -> vPrimToCon p 
      | Unary_exp(_,"!", p) -> Neg(vPrimToCon p)
      | Unary_exp(loc,uop, _) ->  
	  raise(ConErr("Unary Operator "^uop^" not supported",loc))
      | Bin_exp(loc, e1,"&&",e2) -> Conj(vExpToCon e1, vExpToCon e2)
      | Bin_exp(loc, e1,"||",e2) -> Disj(vExpToCon e1, vExpToCon e2)
      | Bin_exp(loc, e1,bop,e2) ->
	  Relation(vExpToConExp e1,boptable loc bop,vExpToConExp e2)
      | Cond_exp(loc, e,e1,e2) ->
	  raise(ConErr("Conditional operator not supported", loc))      
      | String_exp(loc, s) ->
	  raise(ConErr("String expressions not supported", loc))

and vPrimToCon p = 
  match p with
      Num_primary(_, (_, num)) -> Relation(Literal(int_of_string num),NEQ,Literal(0))
    | Id_primary(_, (_,id,_), No_select) -> Relation(Variable(id),NEQ,Literal(0))
    | Id_primary(loc, _ , _) ->
	raise(ConErr("Signals are not supported", loc))
    | Concat(loc, elist) ->
	raise(ConErr("Concat not supported", loc))
    | Mult_concat(loc, e,elist) ->
	raise(ConErr("Multiple Concat not supported", loc))
    | Mintypmax_primary(loc, mtme) ->
	raise(ConErr("MinTypMax not supported", loc))
;;

let vLvToVExp lv =
  match lv with 
    | Ident_lval(loc, id, sel)-> 
	Primary(None, Id_primary(None, id, sel))
    | Concat_lv(loc, x) ->
	Primary(None, Concat(None, x))
	  
(*************************************************************************)
(* Constraint Generation *************************************************)

type growtype = INC | DEC | STABLE

let rec getvars_exp e =
  match e with
      Variable s -> [s]
    | Literal s -> []
    | Op (e1,_,e2) -> Util.union (getvars_exp e1) (getvars_exp e2)
    | Abs e -> getvars_exp e
    | Power e -> getvars_exp e
    | Min (e1,e2) 
    | Max (e1,e2) 
    | Shiftl (e1,e2)  
    | Shiftr (e1,e2) ->  Util.union (getvars_exp e1) (getvars_exp e2)
let rec getvars cnstnt :string list = 
  match cnstnt with
    | Bool _ -> []
    | Relation (e1,_,e2) -> Util.union (getvars_exp e1) (getvars_exp e2)
    | Conj (c1, c2) -> Util.union (getvars c1) (getvars c2)
    | Disj (c1, c2) -> Util.union (getvars c1) (getvars c2)
    | Neg c -> getvars c

let inv_rop rop =
  match rop with
  | LT -> GTE
  | GT -> LTE
  | LTE -> GT
  | GTE -> LT
  | EQ -> NEQ
  | NEQ -> EQ
let rec negate c = 
  match c with
  | Bool(true) -> Bool(false)
  | Bool(false) -> Bool(true)
  | Relation(e1,rop,e2) -> Relation(e1,inv_rop rop,e2)  
  | Conj(c1,c2) -> Disj(negate c1, negate c2)
  | Disj(c1,c2) -> Conj(negate c1, negate c2)
  | Neg(c1) -> c1


(* Simplify constraints *)
let rec cnstrnt_smpl c =
  match c with
    | Bool(_) -> c 
    | Relation(e1,rop,e2) ->
	let se1 = expression_smpl e1 in
	let se2 = expression_smpl e2 in
	  begin match (se1,se2) with
	    | (Literal(n1),Literal(n2)) -> 		
		begin match rop with
		  | LT -> Bool(n1 < n2)
		  | GT -> Bool(n1 > n2)
		  | LTE -> Bool(n1 <= n2)
		  | GTE -> Bool(n1 >= n2)
		  | EQ -> Bool(n1 = n2)
		  | NEQ -> Bool(n1 <> n2)
		end 
	    | _ -> Relation(se1,rop,se2)
	  end
    | Conj(c1,c2) -> 
	let sc1 = cnstrnt_smpl c1 in
	let sc2 = cnstrnt_smpl c2 in
	  begin match(sc1,sc2) with
	    | (Bool(true),_) -> sc2
	    | (_,Bool(true)) -> sc1
	    | (Bool(false),_) -> sc1
	    | (_,Bool(false)) -> sc2
	    | _ -> Conj(sc1,sc2)
	  end
    | Disj(c1,c2) ->
	let sc1 = cnstrnt_smpl c1 in
	let sc2 = cnstrnt_smpl c2 in
	  begin match(sc1,sc2) with
	    | (Bool(true),_) -> sc1
	    | (_,Bool(true)) -> sc2
	    | (Bool(false),_) -> sc2
	    | (_,Bool(false)) -> sc1
	    | _ -> Disj(sc1,sc2)
	  end
    | Neg(c1) -> negate (cnstrnt_smpl c1)

and expression_smpl e =
  match e with
    | Variable(_) -> e
    | Literal(_) -> e
    | Op(e1,op,e2) -> 
	let se1 = expression_smpl e1 in
	let se2 = expression_smpl e2 in
	  begin match (se1,se2) with
	    | (Literal(n1),Literal(n2)) -> 
		begin match op with
		  | PLUS -> Literal (n1 + n2)
		  | MINUS -> Literal (n1 - n2)
		  | TIMES -> Literal (n1 * n2)
		  | DIV -> Literal (n1 / n2)
		  | MOD -> Literal (n1 mod n2)
		end
	    | _ -> Op(se1,op,se2)
	  end
    | Abs(e) -> 
	let se1 = expression_smpl e in
	  begin match se1 with
	    | Literal(n) -> Literal (abs n)
	    | Power(_) -> se1
	    | _ -> Abs(se1)  
	  end
    | Power(e) ->
	let se1 = expression_smpl e in
	  begin match se1 with
	    | Literal(n) -> Literal(int_of_float (2.0 ** (float_of_int n)))
	    | _ -> Power(se1)
	  end
    | Min(e1,e2) ->
	let se1 = expression_smpl e1 in
	let se2 = expression_smpl e2 in
	  begin match (se1,se2) with
	    | (Literal(n1),Literal(n2)) -> Literal(min n1 n2)
	    | _ -> Min(se1,se2)
	  end
    | Max(e1,e2) ->
	let se1 = expression_smpl e1 in
	let se2 = expression_smpl e2 in
	  begin match (se1,se2) with
	    | (Literal(n1),Literal(n2)) -> Literal(max n1 n2)
	    | _ -> Max(se1,se2) 
	  end
    | Shiftr(e1,e2) ->
	let se1 = expression_smpl e1 in
	let se2 = expression_smpl e2 in
	  begin match (se1,se2) with
	    | (Literal(n1),Literal(n2)) -> Literal(n1 lsr n2)
	    | _ -> Shiftr(se1,se2) 
	  end
    | Shiftl(e1,e2) ->
	let se1 = expression_smpl e1 in
	let se2 = expression_smpl e2 in
	  begin match (se1,se2) with
	    | (Literal(n1),Literal(n2)) -> Literal(n1 lsl n2)
	    | _ -> Shiftl(se1,se2) 
	  end

(* Array bounds checking *)
let myread ctx str = 
  (*Format.eprintf "%s@." str;*)
  let s = Mlyices.yicesl_read ctx str in
    if s = 0 then
      Format.eprintf "Yices Command \"%s\" failed with error message:\n%s@." str (Mlyices.yicesl_get_last_error_message())

let sat_check cs =
  let cs = List.map cnstrnt_smpl cs in
  let vs = Util.unionall (List.map getvars cs) in
  let _ = Mlyices.yicesl_set_output_file "yices.out" in 
  let ctx = Mlyices.yicesl_mk_context () in
    myread ctx "(define min::(-> x::int y::int (subtype (r::int) (and (or (= r x) (= r y)) (<= r x) (<= r y)))))";	
    myread ctx "(define max::(-> x::int y::int (subtype (r::int) (and (or (= r x) (= r y)) (>= r x) (>= r y)))))";
    (*myread ctx "(define pow::(-> nat nat) (lambda (x::nat) (if (= 0 x) 1 (* 2 (pow (- x 1))))))";*)
    myread ctx "(define pow::(-> nat (subtype (r::nat) (>= r 1))))";
    (*myread ctx "(assert (= (pow 0) 1))";
    myread ctx "(assert (= (pow 1) 2))";
    myread ctx "(assert (= (pow 2) 4))";
    myread ctx "(assert (= (pow 3) 8))";*) 
    (*myread ctx "(assert (forall (x::nat) (>= (pow x) 1)))";*)
    myread ctx "(define shiftr::(-> nat nat nat))";
    myread ctx "(define shiftl::(-> nat nat nat))";
    List.iter (fun x -> myread ctx ("(define "^x^" :: int)")) vs;
    List.iter (fun c -> myread ctx ("(assert "^(Printer.constrnt_tostring c)^")")) cs;
    myread ctx "(check)";
    let sat = (Mlyices.yicesl_inconsistent ctx <> 1) in
      Mlyices.yicesl_del_context ctx;
      sat

let prove loc cs c = 
  let (sat,t) = Util.time_fun (fun () -> sat_check (cs@[negate c])) in
    yices_time := (!yices_time +. t); 
    if sat then raise (TypeErr("Constraint "^ (Printer.constrnt_tostring c) ^" cannot be proven",loc))
    else ()

let try_prove cs c = 
  let (sat,t) = Util.time_fun (fun () -> sat_check (cs@[negate c])) in
    yices_time := (!yices_time +. t); 
    not sat

let check_consistency loc cs msg = 
  let (sat,t) = Util.time_fun (fun () -> sat_check cs) in
    yices_time := (!yices_time +. t); 
    if sat then ()
    else raise (TypeErr("Unsatisfiable Constraints: "^msg,loc))

(************************************************************************)
(* Type Checking ********************************************************)

(* Substituting parameter variables in types *)

let rec subConExp x exp c = 
  let sub = subConExp x exp in
    match c with
      | Variable(n) -> if n = x then exp else c
      | Literal(_) -> c
      | Op(e1,op,e2) -> Op(sub e1,op,sub e2)
      | Abs(e) -> Abs(sub e)
      | Power(e) -> Power(sub e)
      | Min(e1,e2) -> Min(sub e1, sub e2)
      | Max(e1,e2) -> Max(sub e1, sub e2)
      | Shiftr(e1,e2) -> Shiftr(sub e1, sub e2) 
      | Shiftl(e1,e2) -> Shiftl(sub e1, sub e2)

let rec subvtp (x:string) (exp:exp) (t:vtype) :vtype =
  match t with
    | INT | BTYPE(_) | TVAR(_) -> t
    | VECT(t1,bs,w) -> 
	let cexp = vExpToConExp exp in 
	let sub = subConExp x cexp in 
	let w2 = sub w in 
	let bs2 = match bs with
	  | Some (l,h) -> Some (sub l, sub h)
	  | None -> None in
	  VECT(t1,bs2,w2)
    | ARR(t1,bs,w) -> 
	let cexp = vExpToConExp exp in 
	let sub = subConExp x cexp in 
	let w2 = sub w in 
	let bs2 = match bs with
	  | Some (l,h) -> Some (sub l, sub h)
	  | None -> None in
	  ARR(subvtp x exp t1,bs2,w2)

(* Type Unification: Needed due to polymorphism *)
let rec tsubst tv t1 t = 
  match t with
    | INT | BTYPE _ | VECT _ -> t
    | TVAR(tv1) -> if tv = tv1 then t1 else t
    | ARR(t2,eo,e) -> ARR(tsubst tv t1 t2,eo,e)

let tsubst_tcs tv t1 tcs =
  List.map (fun (lt,rt) -> (tsubst tv t1 lt,tsubst tv t1 rt)) tcs

let rec unify tcs loc = 
  match tcs with 
    | [] -> []
    | (t1,t2)::t when t1=t2 -> unify t loc
    | (TVAR(tv),t2)::t -> (tv,t2)::(unify (tsubst_tcs tv t2 t) loc)
    | _ -> raise(TypeErr("Unification failed",loc))  

(* Need to make sure that no variable is mentioned twice: once as being an array
   and once as being a single element *)
(* type checking a program *)
let rec tc_program (p:source_text) (tc_only:bool): graph =
  match p with
    | Source_text(loc,_,[]) -> raise(TypeErr("A description must have at least one module definition",loc))
    | Source_text(loc,mtl,ml)-> 
	let menv1 = List.fold_left (fun menv mt -> (tc_module_typ menv mt)::menv) [] mtl in 
	let menv2 = List.fold_left (fun menv m -> (get_module_type menv m)::menv) [] ml in
	let (_,MODULE(tvs,mpl,_,_,_,_)) = List.hd menv2 in
	  if ((List.length tvs <> 0 || List.length mpl <> 0) && not tc_only) then
	    raise(TypeErr("Top level module (last defined module) cannot be a higher order module if elaboration is required",loc))
	  else
	    let menv3 = menv1@menv2 in
	    let edgelsts = List.map (tc_module menv3) ml in
	      List.map2 (fun edl (Module(loc,(_,(_,mn,_)),_,_)) -> 
			   begin match (lookup_menv mn menv3) with
			     | Some (MODULE(_,_,plst,_,_,_)) -> Node(mn,List.map (fun (pn,_,_) -> pn) plst,edl) 
			     | None -> raise(TypeErr("Unexpected: Module type not found in module environment while building graph",loc))
			   end) edgelsts ml 
		
(*TODO: type check portlist types and gate count expression based on parameter names*)
and tc_module_typ (menv:(string*mtype) list) (mt:mod_nm_typ) : (string*mtype)  =
  match mt with 
      ModNameType(mtloc,(_,(_,mn,_)),modparams,parameterlist,portList,gco) -> 
	begin match (lookup_menv mn menv) with
	  | None -> (assumed_mods:= (mn::!assumed_mods);
		     let gceo = 
		       begin match gco with
			 | None -> None
			 | Some gc -> 
			     let gce = vExpToGcExp gc in
			     let _ = gclst := (mn,gce)::!gclst in
			       Some (gce) 
		       end in
		     let paramList = List.map get_parameter_name_and_default parameterlist in
		     let (pnames,pexps,pconds) = Util.split3 paramList in
		     let _ = tc_paramConds mtloc [] pnames pexps pconds true in 
		     let port_dir_type_names = List.map get_port_dir_type_name portList in
		     let poly_types = get_poly_types port_dir_type_names in
		       (mn,MODULE(poly_types,
				  List.map get_modparam_name_and_type modparams,
				  paramList,
				  port_dir_type_names,
				  ref gceo,
				  ASSUMED)))
	  | _ -> raise(TypeErr("Module "^ mn ^" already assumed",mtloc))
	end
	  
and get_type_var t = 
  match t with
    | INT | BTYPE _ | VECT _ -> None
    | TVAR(st) -> Some(st)
    | ARR(t1,_,_) -> get_type_var t1

and get_poly_types dtns = 
  List.fold_left (fun ps (_,t,_) -> 
		    match get_type_var t with
			None -> ps
		      | Some st -> if List.mem st ps then ps else st::ps) [] dtns

and get_port_dir_type_name (d,t,(_,(_,n,_))) = (d,t,n)
    
and get_parameter_name_and_default ((_,(_,pn,_)),exp,oexp) = (pn, Some exp,oexp) 

and get_parameter_name (_,(_,pn,_)) = pn

and get_modparam_name_and_type ((_,(_,nm,_)),mtyp) = (Some nm,mod_typ_to_mtype mtyp)
  
and get_module_type (menv:(string*mtype) list) (m:mod_v) : (string*mtype) =
  match m with
      Module(_,(loc,(_,mn,_)),portList,mitemList) -> 
	begin match (lookup_menv mn menv) with
	  | None -> 
	      let portNames = List.map (fun (_,name) -> name) portList in 
	      let (paramList,portTypeList,local_menv,_,_,_) = tc_declList portNames mitemList [] [] [] [] [] loc in
	      let poly_types = get_poly_types portTypeList in
		(mn,MODULE(poly_types,
			   List.map (fun (n,t) -> (None,t)) local_menv,
			   paramList,
			   portTypeList,
			   ref None,
			   DEFINED))
	  | _ -> raise(TypeErr("Module " ^ mn ^ " already defined", loc))
	end

and update_gate_count menv mn gc = 
  begin match (lookup_menv mn menv) with
    | None ->  raise(TypeErr("Unexpected: Updating gate count for module "^ mn ^" which cannot be found in the environment", None))
    | Some (MODULE(_,_,_,_,g,_)) -> 
	begin match !g with
	  | None -> g := Some gc
	  | Some gcexp -> raise(TypeErr("Unexpected: Updating gate count for module "^ mn ^" which was updated previously", None))
	end 
  end;
  gclst := (mn,gc)::!gclst


(* Type Checking a module given a module environment *)						  
and tc_module (menv:(string*mtype) list) (m:mod_v) : edge list  = 
  match m with
      Module(_,(loc,(_,mn,_)),portList,mitemList) -> 
	let portNames = List.map (fun (_,name) -> name) portList in 
	let (paramList,portTypeList,(local_menv:(string * mtype)list),env,pdims,cs) = tc_declList portNames mitemList [] [] [] [] [] loc in
	let (gc,edges) = (tc_mitemList mitemList (local_menv@menv) env cs) in
	let _ = update_gate_count menv mn gc in
	let _ = (pdimlst := (mn,pdims)::!pdimlst) in
	let _ = (globalenv := (mn,env)::!globalenv) in
	  edges
	  
and mod_typ_to_mtype mt = 
  match mt with
    | ModType (_,mts,ps,prts) ->	
	let port_dir_type_names = List.map get_port_dir_type_name prts in
	let poly_types = get_poly_types port_dir_type_names in
	MODULE(poly_types,
	       List.map (fun m -> (None,mod_typ_to_mtype m)) mts,
	       List.map (fun p -> (get_parameter_name p,None,None)) ps,
	       port_dir_type_names, ref None,PARAM)    

(* Type checking declarations given a portnames list, 
 * a variable environment, a list of parameters (with default values)
 * and the module location (to be used in case of error)
 *) 
and tc_declList portNames mitemList (menv:(string * mtype) list) env pdims cs pList loc =
  match mitemList with
    | [] -> 
	if(envContainsAllPorts portNames env) then 
	  let portTypeList = (extractptList portNames env) in 
	  let (pnames,pexps,pconds) = Util.split3 pList in
	  let _ = tc_paramConds loc [] pnames pexps pconds true in 
	    (pList,portTypeList,menv,env,pdims,cs)
	else
	    raise(TypeErr("Not all port directions have been defined", loc))
    | h::t -> 
	let (menv2,env2,pdims2,pList2,cs2) = (tc_decl (List.map (fun (_,nm,_) -> nm) portNames) menv env pdims cs pList h) in 
	  (tc_declList portNames t menv2 env2 pdims2 cs2 pList2 loc)

and get_param_cs pal = 
  match pal with 
      [] -> []
    | (_,_,_,None)::t -> get_param_cs t
    | (_,_,_,Some c)::t -> (vExpToCon c)::(get_param_cs t)

and tc_paramConds loc cs (pnames:string list) (pexps:exp option list) (pconds:exp option list) (chkCondCons:bool) :unit  =
  let cs2 = List.map2 (fun pn pexp -> 
			begin match pexp with
			    None -> Bool(true) 
			  | Some e -> Relation(Variable(pn),EQ,vExpToConExp e)
			end) pnames pexps in
  let conds = List.map (fun c -> 
			  begin match c with 
			    | None -> Bool(true) 
			    | Some e -> vExpToCon e
			  end) pconds in
  let _ = if chkCondCons then check_consistency loc conds "conflicting parameter constraints" else () in
    List.iter (fun c -> prove loc (cs@cs2) c) conds
      
and tc_decl portNames (menv:(string * mtype)list) env pdims cs pList item =
  match item with
    | Parameter_declaration(loc,pal) -> 
	let env2 = (param_update_env pal env) in
	  (menv,env2,pdims,
	   pList@(List.map (fun (_,(_,vname,_),exp,oexp) ->
			      if ((tc_exp 0 env cs exp) = (IN,INT,(GcLit 0)) &&
				  begin match oexp with
				      None -> true
				    | Some e -> (tc_exp 0 env2 cs e) = (IN,INT,(GcLit 0))
				  end) then
				(vname,Some exp,oexp)
			      else
				raise(TypeErr("Parameter default value or constraint is ill-typed",loc))) pal),
	   cs@(get_param_cs pal))
    | Mod_param_declaration(_,(_,(_,nm,_)),mtp) -> 
	(((nm,mod_typ_to_mtype mtp)::menv),env,pdims,pList,cs)
    | Input_declaration(_,r,idl,b) -> 
	(tc_range r env;
	 tc_bounds b env; 
	 let (env2,pdims2) = (dir_update_env r b IN portNames idl env pdims cs) in
	   (menv,env2,pdims2,pList,cs))
    | Output_declaration(_,r,idl,b) -> 
	(tc_range r env;
	 tc_bounds b env; 
	 let (env2,pdims2) = (dir_update_env r b OUT portNames idl env pdims cs) in 
	   (menv,env2,pdims2,pList,cs))
    | Inout_declaration(_,r,idl,b) -> 
	(tc_range r env;
	 tc_bounds b env;  
	 let (env2,pdims2) = (dir_update_env r b INOUT portNames idl env pdims cs) in 
	   (menv,env2,pdims2,pList,cs))
    | Net_declaration(loc,(_,netType),r,_,idl,b) -> 
	(tc_range r env;
	 tc_bounds b env; 
	 if(netType ="wire") then 
	   let (env2,pdims2) = (type_update_env r b (BTYPE(WIRE)) portNames idl env pdims cs) in 
	     (menv,env2,pdims2,pList,cs)
	 else 
	   raise(TypeErr("Net declaration other than wire are not supported", loc)))
    | Var_declaration(loc,str,idl,b) -> 
	(tc_bounds b env; 
	 let (env2,pdims2) = (type_update_env No_range b (TVAR(str)) portNames idl env pdims cs) in 
	   (menv,env2,pdims2,pList,cs))
    | Reg_declaration(_,r,idl,b) -> 
	(tc_range r env;
	 tc_bounds b env;  
	 let (env2,pdims2) = (type_update_env r b (BTYPE(REG)) portNames idl env pdims cs) in 
	   (menv,env2,pdims2,pList,cs))
    | Int_declaration(_,idl,b) -> 
	(tc_bounds b env;        
	 let env2 = (int_update_env b portNames idl env cs) in 
	   (menv,env2,pdims,pList,cs))
    | Genvar_declaration(_,idl) -> 
	(let env2 = (int_update_env No_bounds portNames idl env cs) in 
	   (menv,env2,pdims,pList,cs))
    | _ -> (menv,env,pdims,pList,cs)


and tc_mitemList mitemList menv env constraints = 
  List.fold_left (fun (gc,edges) mi -> 
		    let (g1,e1) = (tc_mitem menv env constraints mi) in
		      (mkgcop "+" [gc;g1],(edges@e1))) (GcLit(0),[]) mitemList

and envContainsAllPorts portNames env = 
  match portNames with
    | [] -> true
    | (_,pn,sub)::t-> 
       (match (lookup_env (pn,sub) env) with
	  | None 
	  | Some (NODIR,_,_) -> false
	  | _ -> envContainsAllPorts t env)

and extractptList portNames env = 
  match portNames with
    | [] -> []
    | (loc,pn,isSub)::t-> 
	(match (lookup_env (pn,isSub) env) with
	   | None -> raise(TypeErr("The direction of port "^ pn ^" was never defined",loc))
	   | Some (d,ty,_) -> (d,ty,pn)::(extractptList t env))
									     
and tc_mitem menv env cs item : (gcexp * edge list)  =
  match item with
    | Continuous_assign(_,_,al) -> (tc_assignList env cs al,[]) 
    | Gate_declaration(_,_,_,gil) -> 
	let gc = tc_gate_instanceList gil env cs in
	  ((mkgcop  "+" [gc;(GcLit(List.length gil))]),[])
    | Instantiation(loc,(_,(_,mn,_)),modList,expList,(_,_,conList),sigma) -> 
	(tc_inst mn modList expList conList menv env cs sigma loc,
	 [Edge(cs,expList,mn)])
    | P_if_stmt(loc,exp,milist) -> 
	let (dir,typ,gc) = (tc_exp 0 env cs exp) in 
	  if ( is_in_dir dir && gc = (GcLit 0)) then
	    let new_cs = (vExpToCon exp)::cs in
	    let _ = check_consistency loc new_cs "Unreachable code detected" in
	    let (gcs1,edges1) = List.split(List.map (tc_mitem menv env new_cs) milist) in
	    let cond = vExpToGcExp exp in
	    let sgc = gclistsum gcs1 in 
	      ((mkgccond cond sgc (GcLit 0)),List.flatten edges1) 
	  else
	    raise(TypeErr("If conditional expression must be readable", loc)) 
    | P_if_else_stmt(loc,exp,milist1,milist2) -> 
	let (dir,typ,gc) = (tc_exp 0 env cs exp) in 
	  if (is_in_dir dir && gc = (GcLit 0)) then 
	    let new_cs1 = (vExpToCon exp)::cs in
	    let _ = check_consistency loc new_cs1 "Unreachable code detected" in
	    let new_cs2 = (negate (vExpToCon exp))::cs in
	    let _ = check_consistency loc new_cs2 "Unreachable code detected" in
	    let (gcs1,edges1) = List.split(List.map (tc_mitem menv env new_cs1) milist1) in
	    let (gcs2,edges2) = List.split(List.map (tc_mitem menv env new_cs2) milist2) in
	    let cond = vExpToGcExp exp in
	    let sgc1 = gclistsum gcs1 in
	    let sgc2 = gclistsum gcs2 in 
	      ((mkgccond cond sgc1 sgc2),List.flatten (edges1@edges2)) 
	  else 
	    raise(TypeErr("If conditional expression must be readable", loc)) 
    | P_for_stmt(loc,alt1,exp2,alt2,milist) -> (*TODO add support for more loop forms*)
	((tc_for_initial_list alt1 env cs);
	 let extenv = (tc_for_extend_env alt1 env) in
	   if ((tc_exp 0 extenv cs exp2) <> (IN,INT,(GcLit 0))) then
             raise(TypeErr("Illegal for condition", loc))
	   else	
             ((tc_for_inc_list alt2 env cs extenv);
	      let c = vExpToCon exp2 in  
              let initgivs = List.map (get_init_constraint alt2) alt1 in
	      let new_cs = (Util.unionall [[c];initgivs;cs]) in
	      let _ = check_consistency loc new_cs "Unreachable code detected" in
              let (gcs,edges) = List.split(List.map (tc_mitem menv extenv new_cs) milist) in 
	      let (y,e1) = 
		(match List.hd alt1 with 
		   | (_,(Ident_lval(_,(_,y,_),_)),e1) -> (y,e1) 
		   | _ -> raise (TypeErr("unsupported loop initiatilization",loc))) in 
	      let e2 = 
		(match exp2 with
		   | (Bin_exp(_,_,"<",e2)) -> e2 
		   | _ -> raise (TypeErr("unsupported loop condition",loc))) in
	      let e3 = 
		(match List.hd alt2 with
		   | (_,_,(Bin_exp(_,_,"+",e3))) -> e3 
		   | _ -> raise (TypeErr("unsupported loop inicrement",loc))) in
	      let e1 = vExpToGcExp e1 in
	      let e2 = vExpToGcExp e2 in
	      let e3 = vExpToGcExp e3 in
	      let sgcs = gclistsum gcs in
	      let gc =  mkgcsum y (mkgcop "/" [e1;e3]) (mkgcop "/" [(mkgcop "-" [e2;(GcLit 1)]);e3]) (gcsub_exp y (mkgcop "*" [GcVar(y);e3]) sgcs) 
	      in
		(gc,List.flatten edges)))
    | P_case_stmt(loc,exp,pcilist) -> 	    
	raise(TypeErr("Unexpected: Case expressions are not supported in the currect version",loc))
    | Always_statement(loc,_) -> 
	raise(TypeErr("Unexpected: Behavioral descriptions (including initial and always blocks) are not supported",loc))
    | _ -> (GcLit(0),[])


and get_init_constraint incl asgn =
  let (loc, lv,exp) = asgn in
    match lv with
      | Ident_lval(_, id, No_select) -> 
	  (match (find_inc_grow id incl) with
	     | STABLE -> Relation(vExpToConExp (vLvToVExp lv),EQ,vExpToConExp exp)
	     | INC -> Relation(vExpToConExp (vLvToVExp lv),GTE,vExpToConExp exp)
	     | DEC -> Relation(vExpToConExp (vLvToVExp lv),LTE,vExpToConExp exp))
      | _->
	  raise(ConErr("Only simple identifiers can be used in loop initializers",
		       loc))
and find_inc_grow id incl =
  match incl with
    | [] -> STABLE
    | (_, Ident_lval(_,x,No_select), exp) :: t -> 
	let (_,x,_) = x in
	let (_,v,_) = id in
	  if v = x then 
	    find_grow exp
	  else
	    find_inc_grow id t
    | _ -> raise(ConErr("Unsupported increment expression",None))	      

and find_grow exp =
  match exp with
    | Bin_exp(_, e1,op,e2) ->
	(match op with
	   |	"+" -> INC
	   |	"*" -> INC
	   |	"-" -> DEC
	   |	"/" -> DEC
	   |	_ -> STABLE)
    | _ -> STABLE

and tc_range r env =
  match r with 
      No_range -> ()
    | Range(_,e1,e2) -> 
	let _ = tc_exp 0 env [] e1 in  
	let _ = tc_exp 0 env [] e2 in ()

and tc_bounds bs env =
  match bs with 
      No_bounds -> ()
    | Bounds(_,e1,e2,b) -> 
	let _ = tc_exp 0 env [] e1 in  
	let _ = tc_exp 0 env [] e2 in 
	  tc_bounds b env; ()

and param_update_env pal env =
  match pal with 
    | [] -> env
    | (loc,(_,vname,isSub),exp,_)::t -> 
	(isSub:=true;if((tc_exp 0 env [] exp) = (IN,INT,(GcLit 0))) then
	   let env2 = (((vname,isSub),IN,INT,0)::env) in (param_update_env t env2)
	 else 
	   raise(TypeErr("parameter value must be an integer", loc)))

and get_min_max_width e1 e2 cs = 
  let c1 = vExpToConExp e1 in
  let c2 = vExpToConExp e2 in
  let (l,h) =
    if try_prove cs (Relation(c1,LTE,c2)) then (c1,c2) 
    else if try_prove cs (Relation(c2,LTE,c1)) then (c2,c1)
    else (Min(c1,c2),Max(c1,c2)) in
  let w = expression_smpl (Op(Op(h,MINUS,l),PLUS,Literal(1))) in
    (l,h,w)

and size_update_type (typ:vtype) r b cs :vtype =
  let typ = match r with
    | No_range -> typ 
    | Range(_,e1,e2) -> 
	let (l,h,w) = get_min_max_width e1 e2 cs in
	  begin match typ with
	    | BTYPE(btp) -> VECT(btp,Some(l,h),w) 
	    | _ -> raise(TypeErr("Unexpected: found a bit vector of a non-base type",None))
	  end
  in
  match b with
    | No_bounds  -> typ
    | Bounds(_,e1,e2,b1) -> 
	let (l,h,w) = get_min_max_width e1 e2 cs in
	  ARR(size_update_type typ No_range b1 cs,Some(l,h),w)
	    
and get_dim bs = 
  match bs with
    | No_bounds -> 0
    | Bounds(_,_,_,b) -> 1 + get_dim b

and dir_update_env r b dir portNames idl env pdims cs =
  match idl with 
    | [] -> (env,pdims)
    | (loc,(_,id,sub))::t ->  
	if (List.mem id portNames) then 
	  (match (lookup_env (id,sub) env) with
	     | None -> 	     
		 let typ2 = size_update_type (BTYPE(WIRE)) r b cs in
		 let env2 = (((id,sub),dir,typ2,1)::env) in 
		 let pdims2 = ((id,get_dim b)::pdims) in
		   (dir_update_env r b dir portNames t env2 pdims2 cs) 
	     | _ -> raise(TypeErr("port direction can be specified only once", loc)))
	else
	  raise(TypeErr("cannot specify direction for a non port", loc))

and type_update_env r b typ portNames idl env pdims cs =
  match idl with 
    | [] -> (env,pdims)
    | (loc,(_,id,sub))::t ->  
	if (List.mem id portNames) then 
	  (match (lookup_env (id,sub) env) with
	     | None
	     | Some(NODIR,_,_) -> raise(TypeErr("port type can only be specified after direction", loc))
	     | Some(dir,ty,l) ->
		 let env2 = (listRemove ((id,sub),dir,ty,l) env) in 
		 let typ2 = size_update_type typ r b cs in
		 let env3 = (((id,sub),dir,typ2,1)::env2) in
		   (type_update_env r b typ portNames t env3 pdims cs))
	else
	  (match (lookup_env (id,sub) env) with
	     | None ->	     
		 let typ2 = size_update_type typ r b cs in
		 let env2 = (((id,sub),INOUT,typ2,1)::env) in 
		 let pdims2 = ((id,get_dim b)::pdims) in
		   (type_update_env r b typ portNames t env2 pdims2 cs) 
	     | _ -> raise(TypeErr("a local variable can be defined only once", loc)))
	   
and int_update_env bs portNames idl env cs =
  match idl with 
    | [] -> env
    | (loc,(_,id,sub))::t -> 
	if (List.mem id portNames) then 
	  raise(TypeErr("A port cannot be declared to be an integer", loc))
	else
	  (match (lookup_env (id,sub) env) with
	     | None -> 
		 let typ = size_update_type INT No_range bs cs in
		 let env2 = (((id,sub),IN,typ,0)::env) in 
		   (int_update_env bs portNames t env2 cs) 
	     | _ -> raise(TypeErr("a local variable can be defined only once", loc)))

and tc_assignList env cs alist =
  List.fold_left (fun gc a -> mkgcop "+" [gc;(tc_assign a env cs)]) (GcLit 0) alist

and width_vector_vtp loc vtp = 
  match vtp with
    | ARR(BTYPE(_),_,w)  
    | VECT(_,_,w) -> w
    | BTYPE _  -> Literal(1) 
    | _ -> raise(TypeErr("Expected bit vector but got: "^Printer.vtype_to_string vtp,loc))

and gen_eq_cs tp1 tp2 exp ispoly loc =
  if tp1 = tp2 then ([],[])
  else match (tp1,tp2) with
    | (_,INT) -> ([(Relation(Op(Power(width_vector_vtp loc tp1),MINUS,Literal(1)),GTE,vExpToConExp exp))],[])
    | (BTYPE _, BTYPE _) -> ([],[])  
    | (TVAR(_),_) when ispoly -> ([],[(tp1,tp2)])
    | (VECT(_,_,w1),BTYPE _) 
    | (BTYPE _,VECT(_,_,w1)) -> ([(Relation(w1,EQ,Literal 1))],[])
    | (ARR(BTYPE(_),_,w1),BTYPE _) 
    | (BTYPE _,ARR(BTYPE(_),_,w1)) -> ([(Relation(w1,EQ,Literal 1))],[])
    | (VECT(_,_,w1),VECT(_,_,w2)) -> ([(Relation(w1,EQ,w2))],[])
    | (ARR(tp3,_,w1),ARR(tp4,_,w2)) -> 
	let (cs,tcs) = (gen_eq_cs tp3 tp4 exp ispoly loc) in ((Relation(w1,EQ,w2))::cs,tcs)
    | _ -> raise(TypeErr("Incompatible types\n\tFirst type: "^ (Printer.vtype_to_string tp1) ^ 
			   "\n\tSecond type: " ^ (Printer.vtype_to_string tp2) ^"\n",loc))

and tc_assign (loc,lv,exp) env cs = 
  let (dir_lv,vtp_lv,_) = (tc_lv 1 env cs lv) in 
  let (dir_exp,vtp_exp,gc) = (tc_exp 1 env cs exp) in 
    if is_out_dir dir_lv then 
      if is_in_dir dir_exp then 
	let (new_cs,tcs) = gen_eq_cs vtp_lv vtp_exp exp false loc  
	in (List.iter (prove loc cs) new_cs; gc) 
      else raise(TypeErr("right hand value of assignment must have in as it's direction", loc))
    else raise(TypeErr("Left hand value of assignment must have out as it's direction", loc))
      
and tc_gate_instanceList gil env cs =
  List.fold_left (fun gc gi -> mkgcop "+" [gc;(tc_gate_instance gi env cs)]) (GcLit 0) gil

and tc_gate_instance (loc,ginm,tl) env cs = 
  let dirtypegcl = List.map (fun e -> tc_exp 1 env cs e) tl in
  let (_,typs,gcs) = Util.split3 dirtypegcl in
    List.iter (fun oc -> match oc with Some c -> prove loc cs c | None -> ()) (List.map (gen_width_1_oc loc) typs);
    let sgcs = gclistsum gcs in
    let fdirtypel = make_dir_types_l (List.length dirtypegcl) loc in
      if (matchPTList dirtypegcl fdirtypel) then sgcs
      else raise(TypeErr("Gate instantiation terminals have wrong directions",loc))

and gen_width_1_oc loc tp =
  match tp with
    | BTYPE(_) -> None
    | VECT(_,_,w) 
    | ARR(BTYPE(_),_,w) -> Some (Relation(w,EQ,Literal(1)))
    | _ -> raise(TypeErr("Gate instantion terminals must be of width 1",loc))

and make_dir_types_l n tlloc =
  if n < 1 then raise(TypeErr("Invalid gate declaration: all gates have at least two terminals",tlloc))
  else if n = 1 then [(OUT,BTYPE(WIRE),"")]
  else (make_dir_types_l (n-1) tlloc)@[(IN,BTYPE(WIRE),"")]
	  	
and tc_inst mn modList expList conList menv env cs sigma loc = 
  match (lookup_menv mn menv) with
    | None ->  raise(TypeErr("Module is referenced without being defined \"" ^ mn ^ "\"", loc))
    | Some mty ->
	if (tc_expList_all_int0 expList env cs) then 
	  begin match conList with 
	    | Mod_port_conn(expList2) ->
		let portTypeGcList1 = (List.map (tc_exp_option 1 env cs) expList2) in
		let (_,_,_,gcs) = Util.split4 portTypeGcList1 in
		let matchedf = matchPTOptionList portTypeGcList1 in 
		  tc_inst_help mn mty modList expList matchedf gcs cs sigma loc 
	    | Named_port_conn(n_expList) ->
		let portTypeGcList1 = (List.map (tc_named_exp_option 1 env cs) n_expList) in
		let (_,_,_,_,gcs) = Util.split5 portTypeGcList1 in 
		let matchedf = matchNamedPTOptionList portTypeGcList1 in 
		  tc_inst_help mn mty modList expList matchedf gcs cs sigma loc
	  end
	else
	  raise(TypeErr("Invalid Instantiation: all passed parameters must be integers.", loc))

and tc_inst_help n mty modList expList matchedf gcs cs sigma loc =
  begin match mty with
    | MODULE(_,modpList,paramList,portTypeList2,_,PARAM) -> 
	if not ((List.length modpList = List.length modList) & 
		  (List.length expList = List.length paramList) & 
		  let (pnames,_,pconds) = Util.split3 paramList in
		  let _ = tc_paramConds loc cs pnames (List.map (fun e -> Some(e)) expList) pconds false in
		  let (matched,tcs) = matchedf portTypeList2 paramList expList loc cs [] in
		  let _ = sigma := Some (unify tcs loc) in
		  (*let _ = List.iter (fun (t1,t2) -> 
				       print_string ("1: sub: " ^ t1 ^ 
					 " with " ^ (Printer.vtype_to_string t2) ^"\n")) sigma in*)
		    matched) 
	then raise(TypeErr("Invalid Instantiation: incorrect number of parameters or non-matcthing port types",loc))
	else mkgcop "+" [(gclistsum gcs);GcMod(n,List.map vExpToGcExp expList)]
    | MODULE(_,modpList,paramList,portTypeList2,gc,_)-> 
	if not ((List.length modpList = List.length modList) &
		  ((List.length expList = List.length paramList) or (List.length expList = 0)) &
		  let _ = if List.length expList <> 0 then
		    let (pnames,_,pconds) = Util.split3 paramList in
		      tc_paramConds loc cs pnames (List.map (fun e -> Some(e)) expList) pconds false 
		  else () in
		  let (matched,tcs) = matchedf portTypeList2 paramList expList loc cs [] in 
		  let _ = sigma := Some (unify tcs loc) in
		  (*let _ = List.iter (fun (t1,t2) -> 
				       print_string ("2: sub: " ^ t1 ^ 
					 " with " ^ (Printer.vtype_to_string t2) ^"\n")) sigma in*)
		    matched) 
	then raise(TypeErr("Invalid Instantiation: incorrect number of parameters or non-matcthing port types",loc))
	else mkgcop "+" [(gclistsum gcs);
			 let (ps,vs) = List.split 
			   (List.map (fun (p,v,_) -> 
					match v with 
					    None -> raise(TypeErr("Unexpected: default value not found",loc))
					  | Some e -> (p,e)) paramList) in
			 let vs = List.map vExpToGcExp (if (List.length expList = List.length paramList) then expList else vs) in 
			   match !gc with
			     | None -> GcMod(n,vs)
			     | Some gc -> (List.fold_right2 gcsub_exp ps vs gc)
			]
  end

    
and tc_expList_all_int0 expList env cs = 
  match expList with
    | [] -> true
    | h::t -> 
	if ((tc_exp 0 env cs h) = (IN,INT,(GcLit 0))) 
	then (tc_expList_all_int0 t env cs) 
	else false

and tc_exp_option l env cs expon =
  match expon with
    | Some(exp) -> let (dir,tp,gc) = tc_exp l env cs exp in (Some(dir),Some(tp),Some(exp),gc)
    | None -> (None,None,None,(GcLit 0))
	
and tc_named_exp_option l env cs nexpon =
  match nexpon with (n,expon) ->
    (match expon with 
       | Some(exp) -> let (dir,typ,gc) = (tc_exp l env cs exp) in (Some(dir),Some(typ),Some(exp),n,gc)
       | None -> (None,None,None,n,(GcLit 0)))
	
and matchNamedPTOptionList olist1 list2 paramlist explist loc cs tcs =
  match olist1 with
    | [] -> (true,tcs)
    | (None,None,None,_,_)::t -> matchNamedPTOptionList t list2 paramlist explist loc cs tcs
    | (Some d1,Some tp1,Some exp1,n1,_)::t -> 
	let (d2,tp2) = lookup_typl list2 n1 in
	  if is_subset_dir d2 d1 then 
	    (let (new_cs,new_tcs) = 
	       if List.length explist = 0 then
		 gen_eq_cs (List.fold_left (fun tp (x,e,_) -> 
					      match e with
						| None -> raise(TypeErr("Unexpected: no parameter default values found",loc))
						| Some exp -> subvtp x exp tp) tp2 paramlist) tp1 exp1 true loc
	       else
		 let (pnames,_,pconds) = Util.split3 paramlist in
		 let _ = tc_paramConds loc cs pnames (List.map (fun e -> Some e) explist) pconds false in
		   gen_eq_cs (List.fold_left2 (fun tp (x,_,_) exp -> subvtp x exp tp) tp2 paramlist explist) tp1 exp1 true loc in
	       List.iter (prove loc cs) new_cs;
	       matchNamedPTOptionList t list2 paramlist explist loc cs (tcs@new_tcs)) 
	  else (false,tcs)
    | _ -> raise(TypeErr("unexpected Error",loc))
	  
and lookup_typl typl n =
  let (loc,nm,_) = n in 
    match typl with
      | [] -> raise(TypeErr("Port Does not exist",loc))
      | (d,tp,name)::t ->  if (nm=name) then (d,tp) else lookup_typl t n
       
and matchPTOptionList olist1 list2 paramlist explist loc cs tcs = 
  match (olist1,list2) with
    | ([],[]) -> (true,tcs)
    | ([],_) -> (false,tcs)
    | (_,[]) -> (false,tcs)
    | ((None,None,None,_)::t1, _::t2) -> matchPTOptionList t1 t2 paramlist explist loc cs tcs
    | ((Some d1,Some tp1,Some exp1,_)::t1,(d2,tp2,_)::t2) -> 
	if is_subset_dir d2 d1 then 
	  (let (new_cs,new_tcs) = 
	     if List.length explist = 0 then
	       gen_eq_cs (List.fold_left (fun tp (x,e,_) -> 
					    match e with
					      | None -> raise(TypeErr("Unexpected: no parameter default values found",loc))
					      | Some exp -> subvtp x exp tp) tp2 paramlist) tp1 exp1 true loc
	     else
	       gen_eq_cs (List.fold_left2 (fun tp (x,_,_) exp -> subvtp x exp tp) tp2 paramlist explist) tp1 exp1 true loc in
	     List.iter (prove loc cs) new_cs; 	    
	     matchPTOptionList t1 t2 paramlist explist loc cs (tcs@new_tcs)) 
	else (false,tcs)
    | _ -> raise(TypeErr("Unexpected Error",loc))

and matchPTList list1 list2 =
  match (list1,list2) with
    | ([],[]) -> true
    | ([],_) -> false
    | (_,[]) -> false
    | ((d1,_,_)::t1,(d2,_,_)::t2) -> 
	if is_subset_dir d2 d1 then matchPTList t1 t2 else false
	
and tc_for_initial_list al env cs =
  match al with
    | [] -> ()
    | (loc,lv,exp)::t -> 
	if (((tc_lv 1 env cs lv) <> (IN,INT,(GcLit 0))) or
	      ((tc_exp 0 env cs exp) <> (IN,INT,(GcLit 0))))
	then raise(TypeErr("Illegal assignment in for initialization",loc))
	else tc_for_initial_list t env cs
	
and tc_for_inc_list al env cs extenv=
  match al with
    | [] -> ()
    | (loc,lv,exp)::t -> 
	if (((tc_lv 1 env cs lv) <> (IN,INT,(GcLit 0))) or
	      ((tc_exp 0 extenv cs exp) <> (IN,INT,(GcLit 0))))
	then raise(TypeErr("Illegal assignment in for increment", loc))
	else tc_for_inc_list t env cs extenv
	
(* TODO: Check if this is really needed *)
and tc_for_extend_env al env =
  match al with
    | [] -> env
    | (loc,lv,_)::t -> 
	(match lv with 
	   | Ident_lval(_,(_,vname,_),No_select) -> 
	       ((vname,ref true),IN,INT,0)::tc_for_extend_env t env
	   |_-> raise(TypeErr("Unsupported for initialization", loc)))
	
and tc_expList_all_int1 elist env cs loc=
  match elist with
    | [] -> ()
    | h::t -> let (dir,typ,gc) = (tc_exp 1 env cs h) in
	if ((dir,typ)=(IN,INT) or (dir,typ)=(INOUT,INT)) then 
	  tc_expList_all_int1 t env cs loc
	else
	  raise(TypeErr("Illegal Case Item Expression", loc))

and tc_exp l env cs exp : dir * vtype * gcexp =
  match exp with
    | Primary(_,p) -> tc_primary p l env cs
    | Unary_exp(loc,op,p) -> 
	let (dir,typ,gc) = (tc_primary p l env cs) in 
	  if is_in_dir dir then 
	    let (t1,gc1) = phi op l [typ] loc in 
	      (dir,t1,mkgcop "+" [gc;gc1])
	  else raise(TypeErr("Incorrect Expression 1", loc))
    | Bin_exp(loc,exp1,op,exp2) -> 
	let (tlist,gc) = (getExpTypes [exp1;exp2] l env cs) in 
	let (t1,gc1) = phi op l tlist loc in
	  (IN,t1,mkgcop "+" [gc1;gc])
    | Cond_exp(loc,exp1,exp2,exp3) -> 
	let (tlist,gc) = (getExpTypes [exp1;exp2;exp3] l env cs) in 
	let (t1,gc1) = phi "?" l tlist loc in
	  (IN,t1,mkgcop "+" [gc1;gc])
    | String_exp(loc,_)-> raise(TypeErr("String constants are not supported", loc))
	
and tc_select sel typ env cs =
  match sel with
    | No_select -> typ
    | Bit_select(loc,index,sel2) ->
	if ((tc_exp 0 env cs index) = (IN,INT,(GcLit 0))) then 	    
	  (match typ with
	     | VECT(typ2,Some(l,h),_) ->
		 prove loc cs (Relation(vExpToConExp index,GTE,l));
		 prove loc cs (Relation(vExpToConExp index,LTE,h));
		 tc_select sel2 (BTYPE(typ2)) env cs
	     | ARR(typ2,Some(l,h),_) -> 
		 prove loc cs (Relation(vExpToConExp index,GTE,l));
		 prove loc cs (Relation(vExpToConExp index,LTE,h));
		 tc_select sel2 typ2 env cs
	     | _ -> raise(TypeErr("Bit-selecting from a non-array or vector",loc)))
	else raise(TypeErr("Array index must be integer",loc))
    | Part_select(loc,st,en,sel2) ->
	if (((tc_exp 0 env cs st) = (IN,INT,(GcLit 0))) & ((tc_exp 0 env cs en) = (IN,INT,(GcLit 0)))) then
	  (match typ with
	     | VECT(typ2,Some(l,h),_) ->
		 prove loc cs (Relation(vExpToConExp st,GTE,l));
		 prove loc cs (Relation(vExpToConExp st,LTE,h));
		 prove loc cs (Relation(vExpToConExp en,GTE,l));
		 prove loc cs (Relation(vExpToConExp en,LTE,h));
		 tc_select sel2 (size_update_type (BTYPE(typ2)) (Range(None,st,en)) No_bounds cs) env cs
	     | ARR(typ2,Some(l,h),_) -> 
		 prove loc cs (Relation(vExpToConExp st,GTE,l));
		 prove loc cs (Relation(vExpToConExp st,LTE,h));
		 prove loc cs (Relation(vExpToConExp en,GTE,l));
		 prove loc cs (Relation(vExpToConExp en,LTE,h));
		 tc_select sel2 (size_update_type typ2 No_range (Bounds(None,st,en,No_bounds)) cs) env cs
	     | _ -> raise(TypeErr("Part selecting from a non-array or vector",loc)))
	else raise(TypeErr("Array indices must be integers",loc))
	  
and is_int_vtype typ =
  match typ with
    | INT | ARR(INT,_,_) -> true
    | _ -> false

and sum_vtp_widths tps loc = 
  let ws = List.map (width_vector_vtp loc) tps in 
    List.fold_left (fun acc w -> Op(acc,PLUS,w)) (Literal 0) ws  

and tc_primary pri l env cs :dir *vtype * gcexp =
  match pri with
    | Num_primary(_,_)-> (IN,INT,(GcLit 0)) 
    | Id_primary(_,(loc,vname,isSub),sel) -> 
	(match (lookup_env (vname,isSub) env) with
	   | None
	   | Some(NODIR,_,_) -> raise(TypeErr("Variable " ^vname^ " not typed in this level", loc))
	   | Some(dir,vtype,level) -> 
	       let vtype2 = tc_select sel vtype env cs in
		 (if ( (level = 1 & l=1) or
			 (level = 0 & dir=IN & is_int_vtype vtype2 ) ) 
		  then (dir,vtype2,(GcLit 0)) 
		  else raise(TypeErr("Variable " ^vname^ " not typed in this level", loc))))
    | Concat(loc,elist) -> 
	let (tps,gc) = tc_expList l env cs elist in 
	(INOUT,VECT(WIRE,None,sum_vtp_widths tps loc),gc) 
    | Mult_concat(loc,e1,elist) -> 
	if ((tc_exp 0 env cs e1) = (IN,INT,(GcLit 0))) 
	then (let (tps,gc) = tc_expList l env cs elist in 
		(INOUT,VECT(WIRE,None,Op(vExpToConExp e1,TIMES,sum_vtp_widths tps loc)),gc)) 
	else raise(TypeErr("Invalid Multiple concatenation", loc))
    | Mintypmax_primary(_,mtme) -> 
	(match mtme with
	   |Exp_mtm(_,e) -> tc_exp l env cs e
	   |Mintypmax(loc,e1,e2,e3)-> raise(TypeErr("Mintypmax expression are not supported", loc)))
	  
and getExpTypes elist l env cs =
  match elist with
    | [] -> ([],(GcLit 0))
    | h::t -> 
	let (dir,typ,gc) = (tc_exp l env cs h) in 
	let (tl,gc1) = getExpTypes t l env cs in
	  (typ::tl,mkgcop "+" [gc;gc1])
						    
(* phi returns the type (including size) and number of gates of the result *)						    
(* Verilog operators:
Unary:
+,-      Positive, Negative
!        Logical negation
~        Bitwise negation
&,~&     Reduction and, nand 
|,~|     Reduction or, nor 
^,~^,^~  Reduction xor, xnor 

Binary: 
||             logical or
&&             logical and
|              Bitwise or
^,^~           Bitwise xor, xnor
&              Bitwise and
==,!=,===,!==  Equality
<,<=,>,>=      Inequality
<<,>>,<<<,>>>  Logical shift and arithmetic shift
+,-            Addition, Subtraction
*,/,%          Multiply, Divide, Modulo
**             Power

Other:
?:             if/else
{a,b,c}        Concatenation
{n{m}}         Repication
*)
and phi op l typelist loc = 
  match(op,l,typelist) with
      ("+",0,[INT]) -> (INT,(GcLit 0))
    | ("-",0,[INT]) -> (INT,(GcLit 0))
    | ("!",0,[INT]) -> (INT,(GcLit 0))
    | ("!",1,[BTYPE(WIRE)]) -> (BTYPE(WIRE),(GcLit 1))
    | ("!",1,[ARR(BTYPE(WIRE),_,(Literal 1))]) -> (ARR(BTYPE(WIRE),None,(Literal 1)),(GcLit 1))
    | ("!",1,[VECT(WIRE,_,(Literal 1))]) -> (VECT(WIRE,None,(Literal 1)),(GcLit 1))
    | ("~",1,[BTYPE(WIRE)]) -> (BTYPE(WIRE),(GcLit 1))
    | ("~",1,[ARR(BTYPE(WIRE),_,(Variable n))]) -> (ARR(BTYPE(WIRE),None,(Variable n)),(GcVar n)) 
    | ("~",1,[VECT(WIRE,_,(Variable n))]) -> (VECT(WIRE,None,(Variable n)),(GcVar n)) 
      (*reduction operators*)
    | ("&",1,[ARR(BTYPE(WIRE),_,_)]) -> (BTYPE(WIRE),(GcLit 1)) 
    | ("~&",1,[ARR(BTYPE(WIRE),_,_)]) -> (BTYPE(WIRE),(GcLit 1)) 
    | ("|",1,[ARR(BTYPE(WIRE),_,_)]) -> (BTYPE(WIRE),(GcLit 1)) 
    | ("~|",1,[ARR(BTYPE(WIRE),_,_)]) -> (BTYPE(WIRE),(GcLit 1)) 
    | ("^",1,[ARR(BTYPE(WIRE),_,_)]) -> (BTYPE(WIRE),(GcLit 1)) 
    | ("~^",1,[ARR(BTYPE(WIRE),_,_)]) -> (BTYPE(WIRE),(GcLit 1)) 
    | ("^~",1,[ARR(BTYPE(WIRE),_,_)]) -> (BTYPE(WIRE),(GcLit 1)) 
    | ("&",1,[VECT(WIRE,_,_)]) -> (BTYPE(WIRE),(GcLit 1)) 
    | ("~&",1,[VECT(WIRE,_,_)]) -> (BTYPE(WIRE),(GcLit 1)) 
    | ("|",1,[VECT(WIRE,_,_)]) -> (BTYPE(WIRE),(GcLit 1)) 
    | ("~|",1,[VECT(WIRE,_,_)]) -> (BTYPE(WIRE),(GcLit 1)) 
    | ("^",1,[VECT(WIRE,_,_)]) -> (BTYPE(WIRE),(GcLit 1)) 
    | ("~^",1,[VECT(WIRE,_,_)]) -> (BTYPE(WIRE),(GcLit 1)) 
    | ("^~",1,[VECT(WIRE,_,_)]) -> (BTYPE(WIRE),(GcLit 1)) 
      (*end of reduction operators*)
    | ("||",0,[INT;INT]) -> (INT,(GcLit 0))
    | ("||",1,[BTYPE(WIRE);BTYPE(WIRE)]) -> (BTYPE(WIRE),(GcLit 1))
    | ("||",1,[ARR(BTYPE(WIRE),_,(Literal 1));ARR(BTYPE(WIRE),_,(Literal 1))]) -> (ARR(BTYPE(WIRE),None,(Literal 1)),(GcLit 1))
    | ("||",1,[VECT(WIRE,_,(Literal 1));VECT(WIRE,_,(Literal 1))]) -> (VECT(WIRE,None,(Literal 1)),(GcLit 1))
    | ("&&",0,[INT;INT]) -> (INT,(GcLit 0))
    | ("&&",1,[BTYPE(WIRE);BTYPE(WIRE)]) -> (BTYPE(WIRE),(GcLit 1))
    | ("&&",1,[ARR(BTYPE(WIRE),_,(Literal 1));ARR(BTYPE(WIRE),_,(Literal 1))]) -> (ARR(BTYPE(WIRE),None,(Literal 1)),(GcLit 1))
    | ("&&",1,[VECT(WIRE,_,(Literal 1));VECT(WIRE,_,(Literal 1))]) -> (VECT(WIRE,None,(Literal 1)),(GcLit 1))
	(*TODO: generate constraint that m = n for some of the following *)
    | ("|",1,[BTYPE(WIRE);BTYPE(WIRE)]) -> (BTYPE(WIRE),(GcLit 1))
    | ("|",1,[ARR(BTYPE(WIRE),_,(Variable m));ARR(BTYPE(WIRE),_,(Variable n))])  -> (ARR(BTYPE(WIRE),None,(Variable n)),(GcVar n))  
    | ("|",1,[VECT(WIRE,_,(Variable m));VECT(WIRE,_,(Variable n))])  -> (VECT(WIRE,None,(Variable n)),(GcVar n))  
    | ("^",1,[BTYPE(WIRE);BTYPE(WIRE)]) -> (BTYPE(WIRE),(GcLit 1))
    | ("^",1,[ARR(BTYPE(WIRE),_,(Variable m));ARR(BTYPE(WIRE),_,(Variable n))])  -> (ARR(BTYPE(WIRE),None,(Variable n)),(GcVar n))  
    | ("^",1,[VECT(WIRE,_,(Variable m));VECT(WIRE,_,(Variable n))])  -> (VECT(WIRE,None,(Variable n)),(GcVar n))  
    | ("^~",1,[BTYPE(WIRE);BTYPE(WIRE)]) -> (BTYPE(WIRE),(GcLit 1))
    | ("^~",1,[ARR(BTYPE(WIRE),_,(Variable m));ARR(BTYPE(WIRE),_,(Variable n))]) -> (ARR(BTYPE(WIRE),None,(Variable n)),(GcVar n))  
    | ("^~",1,[VECT(WIRE,_,(Variable m));VECT(WIRE,_,(Variable n))]) -> (VECT(WIRE,None,(Variable n)),(GcVar n))  
    | ("&",1,[BTYPE(WIRE);BTYPE(WIRE)]) -> (BTYPE(WIRE),(GcLit 1))
    | ("&",1,[ARR(BTYPE(WIRE),_,(Variable m));ARR(BTYPE(WIRE),_,(Variable n))]) -> (ARR(BTYPE(WIRE),None,(Variable n)),(GcVar n)) 
    | ("&",1,[VECT(WIRE,_,(Variable m));VECT(WIRE,_,(Variable n))]) -> (VECT(WIRE,None,(Variable n)),(GcVar n)) 
    | ("&",1,[t1;t2]) -> (*(print_string ("["^ (Printer.vtype_to_string t1) ^","^(Printer.vtype_to_string t2)^"]\n");*)(BTYPE(WIRE), (GcLit 1))
    | ("==",0,[INT;INT]) -> (INT,(GcLit 0))
    | ("!=",0,[INT;INT]) -> (INT,(GcLit 0))
    | ("===",0,[INT;INT]) -> (INT,(GcLit 0))
    | ("!==",0,[INT;INT]) -> (INT,(GcLit 0))
    | ("<",0,[INT;INT]) -> (INT,(GcLit 0))
    | ("<=",0,[INT;INT]) -> (INT,(GcLit 0))
    | (">",0,[INT;INT]) -> (INT,(GcLit 0))
    | (">=",0,[INT;INT]) -> (INT,(GcLit 0))
    | ("<<",0,[INT;INT]) -> (INT,(GcLit 0))
    | (">>",0,[INT;INT]) -> (INT,(GcLit 0))
    | ("<<<",0,[INT;INT]) -> (INT,(GcLit 0))
    | (">>>",0,[INT;INT]) -> (INT,(GcLit 0))
    | ("+",0,[INT;INT]) -> (INT,(GcLit 0))
    | ("-",0,[INT;INT]) -> (INT,(GcLit 0))
    | ("*",0,[INT;INT]) -> (INT,(GcLit 0))
    | ("/",0,[INT;INT]) -> (INT,(GcLit 0))
    | ("%",0,[INT;INT]) -> (INT,(GcLit 0))
    | ("**",0,[INT;INT]) -> (INT,(GcLit 0))
    | ("?",0,[INT;INT;INT]) -> (INT,(GcLit 0))
    | _ -> raise(TypeErr("Operator " ^ op ^ " not supported on these operand types ("^ 
			   (List.fold_left (fun a b -> a ^ " " ^ (Printer.vtype_to_string b)) "" typelist) ^") at this level (level "^ string_of_int l ^")",loc)) 
 
and tc_lv l env cs lv =
  match lv with 
    | Ident_lval(_,(loc,id,isSub),sel)-> tc_exp l env cs (Primary(loc,Id_primary(loc,(loc,id,isSub),sel)))
    | Concat_lv(loc,elist) -> let (tps,gc) = tc_expList l env cs elist in 	
	(INOUT,ARR(BTYPE(WIRE),None,sum_vtp_widths tps loc),gc) 
       
and tc_expList l env cs elist = 
  match elist with
    | []-> ([],(GcLit 0))
    | h::t -> 
	let (dir,typ,gc) = tc_exp l env cs h in
	let (tps,tgc) = tc_expList l env cs t in
	  (typ::tps,mkgcop "+" [gc;tgc]);;	   

(*************************************************************************)
(* Substitution **********************************************************)

let rec sub_exp x (v:number) exp=
  match exp with
    | Primary(_,p) -> Primary(None,sub_primary p x v)
    | Unary_exp(_,op,p) -> Unary_exp(None,op,(sub_primary p x v))
    | Bin_exp(_,exp1,op,exp2) -> Bin_exp(None,(sub_exp x v exp1),op,(sub_exp x v exp2))
    | Cond_exp(_,exp1,exp2,exp3) -> Cond_exp(None,(sub_exp x v exp1),(sub_exp x v exp2),(sub_exp x v exp3))
    | String_exp(loc,_)-> raise(SubError("String constants are not supported",loc))
  

and sub_primary pri x v =
  match pri with
    | Num_primary(_,n)-> Num_primary(None,n)
    | Id_primary(_,(l,vname,isSub),No_select)->
	if (x=vname) 
	then (if (!isSub) then Num_primary(None,v) else Id_primary(None,(l,vname,isSub),No_select))
        else Id_primary(None,(l,vname,isSub),No_select) 
    | Id_primary(_,vname,sel)-> Id_primary(None,vname,(sub_select sel x v))
    | Concat(_,elist) -> Concat(None,List.map (sub_exp x v) elist)
    | Mult_concat(_,e1,elist) -> Mult_concat(None,sub_exp x v e1,List.map (sub_exp x v) elist)
    | Mintypmax_primary(_,mtme) -> 
	begin match mtme with
	   |Exp_mtm(_,e) -> Mintypmax_primary(None,Exp_mtm(None,sub_exp x v e))
	   |Mintypmax(loc,e1,e2,e3)-> raise(SubError("Mintypmax expression are not supported",loc))
	end
	  
and sub_select sel x v =
  match sel with
      No_select -> No_select
    | Bit_select(_,e1,sel2) -> Bit_select(None,sub_exp x v e1,sub_select sel2 x v)
    | Part_select(_,e1,e2,sel2) -> Part_select(None,sub_exp x v e1, sub_exp x v e2, sub_select sel2 x v)

let sub_exp_option x v expon =
  match expon with
    | Some(exp) -> Some(sub_exp x v exp)
    | None -> None

let sub_lv lv x v =
  match lv with 
     | Ident_lval(_,vname,sel)-> Ident_lval(None,vname,sub_select sel x v) 
     | Concat_lv(_,elist) -> Concat_lv(None,List.map (sub_exp x v) elist)  

let rec sub_for_assign_list x v al = 
  match al with
    | [] -> []
    | (_,lv,exp)::t -> (None,lv,sub_exp x v exp)::sub_for_assign_list x v t

and sub_namedconn x v (n,nexp) =
  (n,sub_exp_option x v nexp)

and sub_conList x v conList =
  match conList with
    | Mod_port_conn(explist) -> Mod_port_conn(List.map (sub_exp_option x v) explist)
    | Named_port_conn(namedconnlist) -> Named_port_conn(List.map (sub_namedconn x v) namedconnlist)

let rec sub_mitem (x:string) (v:number) (item:module_item) :module_item = 
  match item with
    | Parameter_declaration(_,pal) -> Parameter_declaration(None,List.map (sub_pa x v) pal)
    | Mod_param_declaration(_,_,_) -> item 
    | Input_declaration(_,r,idlist,b) -> Input_declaration(None,sub_range r x v,idlist, sub_bounds b x v)
    | Output_declaration(_,r,idlist,b) -> Output_declaration(None,sub_range r x v,idlist, sub_bounds b x v)
    | Inout_declaration(_,r,idlist,b) -> Inout_declaration(None,sub_range r x v,idlist, sub_bounds b x v)
    | Net_declaration(_,netType,r,d,idlist,b)-> Net_declaration(None,netType,sub_range r x v,sub_delay d x v,idlist, sub_bounds b x v)
    | Var_declaration(_,string,idlist,b) -> Var_declaration(None,string,idlist,sub_bounds b x v)
    | Reg_declaration(_,r,idlist,b) -> Reg_declaration(None,sub_range r x v,idlist, sub_bounds b x v)
    | Int_declaration(_,idlist,b)-> Int_declaration(None,idlist, sub_bounds b x v)
    | Genvar_declaration(_,idlist)-> Genvar_declaration(None,idlist)
    | Continuous_assign(_,d,al)->  Continuous_assign(None,sub_delay d x v,List.map (sub_a x v) al)
    | Gate_declaration(loc,gt,d,gil) -> Gate_declaration(None,gt,sub_delay d x v ,List.map (sub_gate_instance x v) gil) 
    | Instantiation(_,mname,modList1,expList1,(_,ins_name,conList),sigma)-> Instantiation(None,mname,modList1, List.map (sub_exp x v) expList1,(None,ins_name, sub_conList x v conList),sigma)
    | P_if_stmt(_,exp,milist) -> P_if_stmt(None,sub_exp x v exp, (List.map (sub_mitem x v) milist))
    | P_if_else_stmt(_,exp,milist1,milist2) -> P_if_else_stmt(None,sub_exp x v exp,(List.map (sub_mitem x v) milist1), (List.map (sub_mitem x v) milist2))
    | P_for_stmt(_,alt1,exp2,alt2,milist) -> 
	let alt3 = sub_for_assign_list x v alt1 in
	let alt4 = sub_for_assign_list x v alt2 in
          P_for_stmt(None,alt3,sub_exp x v exp2,alt4, List.map (sub_mitem x v) milist)
    | P_case_stmt(loc,_,_) -> 	    
	raise(SubError("Unexpected: Case expressions are not supported in the currect version",loc))
    | Always_statement(loc,_) -> 
	raise(SubError("Unexpected: Behavioral descriptions (including initial and always blocks) are not supported",loc))
  
and sub_gate_instance x v (loc,ginm,tl) =
  let stl = List.map (fun e -> sub_exp x v e) tl in
    (None,ginm,stl)

and sub_pa x v (_,id,exp,_) = 
  (None,id,sub_exp x v exp,None)
    
and sub_range r x v =
  match r with 
      No_range -> No_range
    | Range (_,e1,e2) -> Range (None, sub_exp x v e1, sub_exp x v e2)

and sub_bounds bs x v =
  match bs with 
      No_bounds -> No_bounds 
    | Bounds (_,e1,e2,b) -> Bounds (None, sub_exp x v e1, sub_exp x v e2, sub_bounds b x v)
	
and sub_delay d x v = 
  match d with
      No_delay -> No_delay 
    | Num_delay(_,n) -> Num_delay(None,n)
    | Ident_delay(_,(_,name,isSub)) ->
	if (x=name) 
	then (if (!isSub) then Num_delay(None,v) else Ident_delay(None,(None,name,isSub)))
        else Ident_delay(None,(None,name,isSub))
	
and sub_a x v (_,lv,exp) = 
  (None,sub_lv lv x v,sub_exp x v exp)
  
     
(*****************************************************************************************)
(* Expansion *****************************************************************************)

let int_of_exp0 e =
  match e with
      Primary(_,Num_primary(_,(_,sn1))) -> int_of_string sn1
    | _ -> raise(ExError("Expected integer value",None))

let rec ex_exp0 exp =
  match exp with
    | Primary(_,p) -> Primary(None,ex_primary0 p)
    | Unary_exp(loc,op,p) -> Primary(None,Num_primary(None,(None,string_of_int (evalUOp op (ex_primary0 p) loc))))
    | Bin_exp(loc,exp1,op,exp2) -> Primary(None,Num_primary(None,(None,string_of_int (evalBiOp op (ex_exp0 exp1) (ex_exp0 exp2) loc))))
    | Cond_exp(loc,exp1,exp2,exp3) -> Primary(None,Num_primary(None,(None,string_of_int (evalCondOp (ex_exp0 exp1)(ex_exp0 exp2)(ex_exp0 exp3) loc))))
    | String_exp(loc,_) -> raise(ExError("String constants are not supported",loc))

and evalUOp op p loc =
  match p with
    | Num_primary(_,(_,sn))-> 
	let n = int_of_string sn in
	  (match op with
	     | "+" -> n
	     | "-" -> -n
	     | "!" -> if (n = 0) then 1 else 0
	     | _ -> raise (ExError("Unary operator " ^op^ " is not supported",loc)))
    | _ -> raise (ExError("Encountered a non number while evaluating a unary operator application",loc))

and evalBiOp op e1 e2 loc =
  match (e1,e2) with
    | (Primary(loc,Num_primary(_,(_,sn1))),Primary(_,Num_primary(_,(_,sn2)))) ->
        let n1 = int_of_string sn1 in
        let n2 = int_of_string sn2 in
          (match op with
	       "+" -> n1+n2
	     | "-" -> n1-n2
	     | "*" -> n1*n2
	     | "/" -> n1/n2
	     | "%" -> n1 mod n2
	     | ">>" -> n1 lsr n2
	     | ">>>" -> n1 asr n2
	     | "<<" -> n1 lsl n2 
	     | "**" -> int_of_float ((float_of_int n1) ** (float_of_int n2))
	     | "<" -> if (n1<n2) then 1 else 0
	     | ">" -> if (n1>n2) then 1 else 0
	     | "<=" -> if (n1<=n2) then 1 else 0
	     | ">=" -> if (n1>=n2) then 1 else 0
	     | "==" -> if (n1=n2) then 1 else 0
	     | "!=" -> if (n1<>n2) then 1 else 0
	     | _-> raise(ExError("Binary operator " ^op^ " is not supported",loc)))
    | _ -> raise (ExError("Encountered a non number while evaluating a binary operator application",loc))

and evalCondOp e1 e2 e3 loc=
  match (e1,e2,e3) with
    | (Primary(_,Num_primary(_,(_,sn1))),Primary(_,Num_primary(_,(_,sn2))),Primary(_,Num_primary(_,(_,sn3)))) ->
	let n1 = int_of_string sn1 in
	let n2 = int_of_string sn2 in
	let n3 = int_of_string sn3 in
	  if (n1 = 0) then n3 else n2
    | _ -> raise (ExError("Encountered a non number while evaluating a conditional operator application",loc))

and ex_primary0 pri =
  match pri with
    | Num_primary(_,n)-> Num_primary(None,n)
    | Id_primary(loc,vname,_)-> raise(ExError("E-Id0",loc))
    | Concat(loc,explist) -> raise(ExError("Concatenation not supported in level 0",loc))	  
    | Mult_concat(loc,e1,explist) -> raise(ExError("Concatenation not supported in level 0",loc))	  
    | Mintypmax_primary(loc,mtme) -> 
	begin match mtme with
	  |Exp_mtm(_,e) -> 
	     (match (ex_exp0 e) with 
		| Primary(_,p) -> p
		| _ -> raise(ExError("Evaluating an expression returned a non primary",loc)))
	  |Mintypmax(loc,e1,e2,e3)-> raise(ExError("Mintypmax expression are not supported",loc))
	end
	  
let eval_expression e = 
  match expression_smpl e with
    | Literal(n) -> n 
    | _ -> raise(ExError("Infered bounds must be integers",None))

let rec subs_vtype pns pvs tp = 
  List.fold_left2 (fun t pn pv -> sub_vtype pn pv t) tp pns pvs

and sub_vtype pn pv tp = 
  match tp with
    | INT | BTYPE(_) | TVAR(_) -> tp
    | VECT(tp1,None,e) -> VECT(tp1,None,sub_expression pn pv e)
    | VECT(tp1,Some(e1,e2),e) -> VECT(tp1,Some(sub_expression pn pv e1,sub_expression pn pv e2),sub_expression pn pv e)
    | ARR(tp1,None,e) -> ARR(tp1,None,sub_expression pn pv e)
    | ARR(tp1,Some(e1,e2),e) -> ARR(tp1,Some(sub_expression pn pv e1,sub_expression pn pv e2),sub_expression pn pv e)

and sub_expression pn pv exp = 
  match exp with
    | Variable(vname) -> if (pn = vname) then Literal(int_of_number pv) else exp 
    | Literal(_) -> exp
    | Op(e1,op,e2) -> Op(sub_expression pn pv e1,op,sub_expression pn pv e2)
    | Abs(e1) -> Abs(sub_expression pn pv e1)
    | Power(e1) -> Power(sub_expression pn pv e1)
    | Min(e1,e2) -> Min(sub_expression pn pv e1,sub_expression pn pv e2)
    | Max(e1,e2) -> Max(sub_expression pn pv e1,sub_expression pn pv e2)
    | Shiftr(e1,e2) -> Shiftr(sub_expression pn pv e1,sub_expression pn pv e2)
    | Shiftl(e1,e2) -> Shiftl(sub_expression pn pv e1,sub_expression pn pv e2)

let rec ex_exp1 mn pnames pvalues exp =
  match exp with
    | Primary(_,p) -> let prims = ex_primary1 mn pnames pvalues p in
	List.map (fun pr -> Primary(None,pr)) prims
    | Unary_exp(_,op,p) -> let prims = ex_primary1 mn pnames pvalues p in
	List.map (fun pr -> Unary_exp(None,op,pr)) prims
    | Bin_exp(_,exp1,op,exp2) -> Util.map2perm (fun e1 e2 -> Bin_exp(None,e1,op,e2)) (ex_exp1 mn pnames pvalues exp1) (ex_exp1 mn pnames pvalues exp2)
    | Cond_exp(loc,_,_,_) -> raise(ExError("Found conditional at level 1",loc))
    | String_exp(loc,_)-> raise(ExError("String constants are not supported",loc))

and ex_primary1 mn pnames pvalues pri : (primary list) =
  match pri with
    | Num_primary(_,n)-> [Num_primary(None,n)]
    | Id_primary(loc,(_,vname,isSub),sel)->  	
	if (!isSub) then raise(ExError("E-Param1",loc)) else 
	  let d = lookup_dim mn vname in
	  let tp = subs_vtype pnames pvalues (lookup_type mn (vname,isSub)) in
	  let (vnames,sel2) = ex_select d tp [vname] sel in
	    List.map (fun vnm -> Id_primary(None,(None,vnm,isSub),sel2)) vnames
    | Concat(loc,elist) -> 
	let elist2 = List.flatten (List.map (ex_exp1 mn pnames pvalues) elist) in
	  [Concat(None,elist2)]
    | Mult_concat(_,e1,elist) ->  
	let elist2 = List.flatten (List.map (ex_exp1 mn pnames pvalues) elist) in
	  [Mult_concat(None,ex_exp0 e1,elist2)]
    | Mintypmax_primary(_,mtme) -> 
	begin match mtme with
	  |Exp_mtm(_,e) -> List.map (fun e1 -> Mintypmax_primary(None,Exp_mtm(None,e1))) (ex_exp1 mn pnames pvalues e)
	  |Mintypmax(loc,e1,e2,e3)-> raise(ExError("Mintypmax expression are not supported",loc))
	end
	  
and ex_select d tp vnames sel = 
  match d with 
      0 -> (vnames,smpl_ex_select sel)
    | _ -> 
	begin match tp with
	  | ARR(tp2,Some(e1,e2),_) ->
	      begin match sel with
		  No_select ->  
		    let n1 = eval_expression e1 in
		    let n2 = eval_expression e2 in
		    let indices = Util.range n2 n1 in
			let new_vnames = Util.map2perm (fun vnm n -> vnm^"_"^(string_of_int n)) vnames indices in
			  ex_select (d-1) tp2 new_vnames sel
		| Bit_select(_,e1,sel2) -> let n = int_of_exp0 (ex_exp0 e1) in
		    ex_select (d-1) tp2 (List.map (fun vnm -> vnm^"_"^(string_of_int n)) vnames) sel2
		| Part_select(_,e1,e2,sel2) -> 
		    let n1 = int_of_exp0 (ex_exp0 e1) in
		    let n2 = int_of_exp0 (ex_exp0 e2) in
		    let new_vnames = Util.map2perm (fun vnm n -> vnm^"_"^(string_of_int n)) vnames (Util.range n1 n2) in
		      ex_select (d-1) tp2 new_vnames sel2 
	      end
	  | _ -> raise(ExError("Identifier must be an array with known bounds",None))
	end
	  
and smpl_ex_select sel = 
  match sel with
      No_select -> No_select
    | Bit_select(_,e1,sel2) -> Bit_select(None, ex_exp0 e1, smpl_ex_select sel2)
    | Part_select(_,e1,e2,sel2) -> Part_select(None, ex_exp0 e1, ex_exp0 e2, smpl_ex_select sel2)

and lookup_dim (mn:string) (vn:string): int =
  try let dims = List.assoc mn !pdimlst in
    try List.assoc vn dims 
    with _ -> 0
  with _ -> raise(ExError("Port dimensions not found",None))

and lookup_type mn id: vtype =
  try let env = List.assoc mn !globalenv in
    begin match lookup_env id env with
      | None -> raise(ExError("Variable not found in env",None))
      | Some (_,t,_) -> t
    end
  with _ -> raise(ExError("Variable type not found",None))

let ex_lv (mn:string) pnames pvalues lv =
  match lv with 
    | Ident_lval(_,(_,vname,sub),sel)-> 
	  let d = lookup_dim mn vname in
	  let tp = subs_vtype pnames pvalues (lookup_type mn (vname,sub)) in
	  let (vnames,sel2) = ex_select d tp [vname] sel in
	    List.map (fun vnm -> Ident_lval(None,(None,vnm,sub),sel2)) vnames 
    | Concat_lv(_,elist) -> [Concat_lv(None,List.flatten (List.map (ex_exp1 mn pnames pvalues) elist))]

let rec sub_exp_vs lvs vs exp =
  match (lvs,vs) with
    | ([],[]) -> exp
    | ((h1::t1),(h2::t2)) -> (sub_exp_vs t1 t2 (sub_exp h1 h2 exp))
    | _ -> raise(SubError("Lists must be of equal lengths",None))
	
and sub_for_init_assgn lv1ns v1vs lv2s exp2s a =
  match (lv2s,exp2s) with
    | ([],[]) -> a
    | (Ident_lval (_,(_,y2,isSub2),No_select)::t1,h2::t2)-> 
	begin match a with 
	  | (_,Ident_lval (_,(_,y1,isSub1),No_select),exp) ->
	      if (y1=y2) && (isSub1=isSub2) 
	      then (None,Ident_lval (None,(None,y1,isSub1),No_select),(sub_exp_vs lv1ns v1vs h2))
              else (sub_for_init_assgn lv1ns v1vs t1 t2 a)
	  | _  -> raise(SubError("Only unindexed identifier can appear in for initialization",None))
	end
    | _ -> raise(SubError("Lists must be of equal lengths",None))

and sub_for_assign_list x v al = 
  match al with
    | [] -> []
    | (_,lv,exp)::t -> 
	(None,lv,sub_exp x v exp)::sub_for_assign_list x v t

and getExps_from_alist al =
  match al with
    | [] -> []
    | (_,_,exp)::t -> (exp :: getExps_from_alist t)

and getLvs_from_alist al =
  match al with
    | [] -> []
    | (_,lv,_)::t -> lv::(getLvs_from_alist t)

and getNameFromLv lv = 
  match lv with 
    | Ident_lval(_,(_,vname,_),No_select) -> vname
    | _ -> raise(ExError("Identifier expected",None))

and getNumFromExp (exp:exp) :number =
  match exp with 
    | Primary(_,Num_primary(_,n)) -> n
    | _ -> raise(ExError("Number expected",None))

let lookup_sigma tp sigma =
  try List.assoc tp sigma 
  with _ -> raise(ExError("TVAR not found in unification solution",None))

(*let rec get_concrete_type tp sigma = 
  match tp with
    | INT | REG | WIRE -> tp
    | TVAR(t1) -> lookup_sigma t1 sigma
    | ARR(tp1,eo,e) -> ARR(get_concrete_type tp1 sigma,eo,e)
*)

let rec get_range_bounds tp = 
  match tp with
    | INT | BTYPE(_) -> (No_range,No_bounds)
    | VECT(_,Some(e1,e2),_) ->
	let n1 = eval_expression e1 in
	let n2 = eval_expression e2 in 
	  (Range(None,
		Primary(None,Num_primary(None,(None,string_of_int n1))),
		Primary(None,Num_primary(None,(None,string_of_int n2)))),
	   No_bounds)
    | VECT(_,None,w) ->
	let w1 = eval_expression w in 
	  (Range(None,
		 Primary(None,Num_primary(None,(None,string_of_int 0))),
		 Primary(None,Num_primary(None,(None,string_of_int (w1-1))))),
	   No_bounds)
    | ARR(tp1,Some(e1,e2),_) -> 
	let n1 = eval_expression e1 in
	let n2 = eval_expression e2 in 
	let (r1,b1) = get_range_bounds tp1 in
	  (r1,Bounds(None,
		     Primary(None,Num_primary(None,(None,string_of_int n1))),
		     Primary(None,Num_primary(None,(None,string_of_int n2))),
		     b1))
    | ARR(tp1,None,w) -> 
	let w1 = eval_expression w in 
	let (r1,b1) = get_range_bounds tp1 in
	  (r1,Bounds(None,
		     Primary(None,Num_primary(None,(None,string_of_int 0))),
		     Primary(None,Num_primary(None,(None,string_of_int (w1-1)))),
		     b1))
    | TVAR(_) -> raise(ExError("TVAR after substituting concrete types",None))

let rec get_tvar tp = 
  match tp with
    | INT | BTYPE _ | VECT _ -> None
    | TVAR(t1) -> Some(t1)
    | ARR(tp1,_,_) -> get_tvar tp1

let rec combine_bounds bs1 bs2= 
  match (bs1,bs2) with
    | (No_bounds, No_bounds)  
    | (No_bounds, Bounds _) -> bs2
    | (Bounds _, No_bounds) -> bs1
    | (Bounds(_,e1,e2,b), Bounds _) -> Bounds(None,e1,e2,combine_bounds b bs2)

(*let combine_bounds_rb bs1 bs2= 
  match (bs1,bs2) with
    | (No_bounds, No_bounds)  
    | (No_bounds, Bounds _) -> (No_range,bs2)
    | (Bounds(_,e1,e2,b), No_bounds) -> (Range(None,e1,e2),b)
    | (Bounds(_,e1,e2,b), Bounds _) -> (Range(None,e1,e2),combine_bounds b bs2)*)

let adjust_bounds tp r b sigma =
  match get_tvar tp with
      None -> (r,b)
    | Some str -> 
	let tp2 = lookup_sigma str sigma in
	let (r1,b1) = get_range_bounds tp2 in
	  begin match r with
	    | No_range -> (r1,combine_bounds b1 b)
	    | _ -> raise(ExError("Polymorphic types cannot be vectors",None))
	  end
	
let rec ex_mitem (modn:string) pnames pvalues (orig_portList:name_of_port list) (portList:name_of_port list) (ml:mod_v list) (item:module_item) (sigma: (string * vtype) list) : 
    (name_of_port list * module_item list * mod_v list) =
  match item with
    | Parameter_declaration(loc,_) -> raise(ExError("Parameters should be removed",loc))
    | Mod_param_declaration(loc,_,_) -> raise(ExError("Module Parameters should be removed",loc))
    | Input_declaration(_,r1,idlist,b1) ->
	let (_,(_,idn,sub)) = (List.hd idlist) in
	let tp = lookup_type modn (idn,sub) in
	let (r2,b2) = adjust_bounds tp (ex_range r1) (ex_bounds b1) sigma in
	let idllist = List.map (fun id -> get_idl (ex_bounds b2) [id]) idlist in	  
	let portList2 =	List.fold_left2 listportreplace portList idlist idllist in 
	  (portList2,[Input_declaration(None,ex_range r2,List.flatten idllist,No_bounds)],[])
    | Output_declaration(_,r1,idlist,b1) -> 
	let (_,(_,idn,sub)) = (List.hd idlist) in
	let tp = lookup_type modn (idn,sub) in
	let (r2,b2) = adjust_bounds tp (ex_range r1) (ex_bounds b1) sigma in
	let idllist = List.map (fun id -> get_idl (ex_bounds b2) [id]) idlist in
	let portList2 =	List.fold_left2 listportreplace portList idlist idllist in 
	  (portList2,[Output_declaration(None,ex_range r2,List.flatten idllist,No_bounds)],[])
    | Inout_declaration(_,r1,idlist,b1) -> 
	let (_,(_,idn,sub)) = (List.hd idlist) in
	let tp = lookup_type modn (idn,sub) in
	let (r2,b2) = adjust_bounds tp (ex_range r1) (ex_bounds b1) sigma in
	let idllist = List.map (fun id -> get_idl (ex_bounds b2) [id]) idlist in
	let portList2 =	List.fold_left2 listportreplace portList idlist idllist in 
	  (portList2,[Inout_declaration(None,ex_range r2,List.flatten idllist,No_bounds)],[])
    | Net_declaration(_,netType,r,d,idlist,b1)-> 
	let idllist = List.map (fun id -> get_idl (ex_bounds b1) [id]) idlist in
	  (portList,[Net_declaration(None,netType,ex_range r,d,List.flatten idllist,No_bounds)],[])
    | Var_declaration(_,string,idlist,b1)-> 
	let (_,(_,idn,sub)) = (List.hd idlist) in
	let pns = List.map (fun (_,(_,pn,_)) -> pn) orig_portList in
	  if List.mem idn pns then 
	    (portList,[],[]) 
	  else
	    let tp = lookup_type modn (idn,sub) in
	    let (r2,b2) = adjust_bounds tp No_range (ex_bounds b1) sigma in
	      (portList,[Net_declaration(None,(None,"wire"),ex_range r2,No_delay,idlist,ex_bounds b2)],[])
    | Reg_declaration(_,r,idlist,b1) -> 
	let idllist = List.map (fun id -> get_idl (ex_bounds b1) [id]) idlist in
	  (portList,[Reg_declaration(None,ex_range r,List.flatten idllist,No_bounds)],[])
    | Int_declaration(_,idlist,b)-> (portList,[Int_declaration(None,idlist,ex_bounds b)],[]) 
    | Genvar_declaration(_,idlist)-> (portList,[],[]) 
    | Continuous_assign(_,d,al)->  (portList,[Continuous_assign(None,d,List.flatten (List.map (ex_a modn pnames pvalues) al))],[])
    | Gate_declaration(loc,gt,d,gil) -> (portList,[Gate_declaration(None,gt,d,List.map (ex_gate_instance modn pnames pvalues) gil)],[])	  
    | Instantiation(_,mname,modList1,expList1,(_,(_,(_,idndstr,sub)),conlist),sigma2)->
	let sigma = match !sigma2 with 
	  | None -> ref (Some(sigma)) 
	  | Some lst -> if List.length lst = 0 then ref (Some(sigma)) else sigma2 in
	let (_,(_,mn,isSub)) = mname in
	  if (List.mem mn !assumed_mods) then
	    (*let vList1 = List.map getNumFromExp (List.map ex_exp0 expList1) in*)
	    let mn2 = getNewModuleName mn modList1 expList1 in
	    let modinst2 = (None,(None,(None,idndstr^"_"^(string_of_int (lookup_ins !modins_env mn2 idndstr)),sub)),(ex_conList modn pnames pvalues conlist)) in
	      (portList,[Instantiation(None,(None,(None,mn2,isSub)),[],[],modinst2,sigma)],[])
	  else
	    let (mportList,mitemList) = getModuleFromML mname ml in
	    let (pnames2,pvalues2,modps,nonpitems) = (splitParameters mitemList) in
	    let vList1 = (if (expList1 = []) 
			  then List.map (fun p -> Primary(None,Num_primary(None,p))) pvalues2                  
			  else expList1) in
	    let mn2 = getNewModuleName mn modList1 vList1 in
	    let modinst2 = (None,(None,(None,idndstr^"_"^(string_of_int (lookup_ins !modins_env mn2 idndstr)),sub)),(ex_conList modn pnames pvalues conlist)) in
	    let (mportList2,nonpitems2,modules) = 
	      (sub_ex_mitems mn orig_portList mportList nonpitems pnames2 (List.map getNumFromExp (List.map ex_exp0 vList1)) 
		 modps 
		 (List.map (fun (ModParamAssign((_,(_,mn,_)),_,_)) -> mn) modList1) 
		 ml 
		 (match !sigma with None -> [] | Some(sigm) -> sigm)) in
	      if (member_in_modules mn2 modules) then
		(portList,[Instantiation(None,(None,(None,mn2,isSub)),[],[],modinst2,sigma)],modules)
	      else 
		(let newModule = Module(None,(None,(None,mn2,isSub)),mportList2,nonpitems2) in
		   (portList,[Instantiation(None,(None,(None,mn2,isSub)),[],[],modinst2,sigma)],module_append modules [newModule]))
    | P_if_stmt(_,exp,milist) -> 
	let v = ex_exp0 exp in
	  if (int_of_string (snd(getNumFromExp v)) = 1) then	
            ex_mitem_block modn pnames pvalues orig_portList portList ml milist sigma 
	  else
	    (portList,[],[])
    | P_if_else_stmt(_,exp,milist1,milist2) -> 
	let v = ex_exp0 exp in
	  if(int_of_string (snd(getNumFromExp v)) = 1) then
            ex_mitem_block modn pnames pvalues orig_portList portList ml milist1 sigma 
	  else
            ex_mitem_block modn pnames pvalues orig_portList portList ml milist2 sigma 
    | P_for_stmt(_,alt1,exp2,alt2,milist) -> 
	let lv1s = getLvs_from_alist alt1 in
	let exp1s = getExps_from_alist alt1 in
	let lv2s = getLvs_from_alist alt2 in
	let exp2s = getExps_from_alist alt2 in
	let lv1ns = List.map getNameFromLv lv1s in
  	let v1s = List.map ex_exp0 exp1s in
	let v1vs = List.map getNumFromExp v1s in
	let v2 = ex_exp0 (sub_exp_vs lv1ns v1vs exp2) in
	  if(int_of_string (snd(getNumFromExp v2)) = 0) then (portList,[],[])
	  else 
	    let (portList2,exmilist1,exmods1)= ex_mitem_block modn pnames pvalues orig_portList portList ml (sub_mitemlist_vs milist lv1ns v1vs) sigma in
	    let alt3 = List.map (sub_for_init_assgn lv1ns v1vs lv2s exp2s) alt1 in
	    let (portList3,exmilist2,exmods2) = ex_mitem modn pnames pvalues orig_portList portList2 ml (P_for_stmt(None,alt3,exp2,alt2,milist)) sigma in
	      (match exmilist1 with
		 | [] -> (portList3,exmilist2,exmods2)
		 | h::t -> (portList3,List.append exmilist1 exmilist2,module_append exmods1 exmods2))
    | P_case_stmt(loc,_,_) -> 	    
	raise(ExError("Case expressions are not supported in the currect version",loc))
    | Always_statement(loc,_) -> 
	raise(ExError("Behavioral descriptions (including initial and always blocks) are not supported",loc))



and get_idl b idl =
  match b with
      No_bounds -> idl
    | Bounds(_,Primary(_,Num_primary(_,(_,sn1))),Primary(_,Num_primary(_,(_,sn2))),bs) -> 
	let n1 = int_of_string sn1 in 
	let n2 = int_of_string sn2 in 
	let idl2 = Util.map2perm (fun (l1,(l2,id,sub)) n -> (l1,(l2,(id^"_"^(string_of_int n)),sub))) idl (Util.range n1 n2) in
	  get_idl bs idl2
    | _ -> raise(ExError("Bounds were not elaborated into values",None))

(* Replaces the first occurence of a port in the portlist l 
   by a list of ports *)
and listportreplace l x  xs =
  match l with
    | [] -> []
    | h::t ->
	let (_,(_,pn,_)) = h in
	let (_,(_,xn,_)) = x in
	  if pn = xn then List.append xs t
	  else h::(listportreplace t x xs)

and ex_gate_instance mn pnames pvalues (loc,ginm,tl) =
  let extl = List.map (fun e -> List.hd (ex_exp1 mn pnames pvalues e)) tl in
    (None,ginm,extl)

and ex_conList mn pnames pvalues conList =
  match conList with
    | Mod_port_conn(explist) -> Mod_port_conn(List.flatten (List.map (ex_exp_option mn pnames pvalues) explist))
    | Named_port_conn(namedconnlist) -> Named_port_conn(List.flatten (List.map (ex_namedconn mn pnames pvalues) namedconnlist))

and ex_exp_option mn pnames pvalues expon =
  match expon with
    | Some(exp) -> List.map (fun e-> Some(e)) (ex_exp1 mn pnames pvalues exp)
    | None -> [None]

and ex_namedconn mn pnames pvalues (n,exp) =
  List.map (fun e -> (n,e)) (ex_exp_option mn pnames pvalues exp)

(*
and ex_pcilist mn portList ml pcilist =
  match pcilist with
    | []-> (portList,[],[])
    | h::t-> let (portList2,expci,exmods1) = (ex_pci mn portList ml h) in
      let (portList3,expcilist,exmods2) = (ex_pcilist mn portList2 ml t) in 
        (portList3,(expci::expcilist),(module_append exmods1 exmods2))

and ex_pci mn portList ml pci =
  match pci with
    | P_case_item (_,elist,milist) -> 
	let (portList2,exmilist,exmods) = ex_mitem_block mn portList ml milist in      
	  (portList2,P_case_item(None,List.map (ex_exp1 mn) elist,exmilist),exmods)
    | P_case_default(_,milist) -> 
	let (portList2,exmilist,exmods) = ex_mitem_block mn portList ml milist in      
	  (portList2,P_case_default(None,exmilist),exmods) 
*)
and ex_mitem_block mn pnames pvalues orig_portList portList ml milist sigma = 
  List.fold_left (fun (pl,mitms,ms) mi -> 
		    let (pl2,mitms2,ms2) = ex_mitem mn pnames pvalues orig_portList pl ml mi sigma in
		      (pl2,List.append mitms mitms2,module_append ms ms2)) (portList,[],[]) milist 

and sub_mitemlist_vs milist lvs vs =
  match (lvs,vs) with
    | ([],[]) -> milist
    | ((h1::t1),(h2::t2)) -> (sub_mitemlist_vs (List.map (sub_mitem h1 h2) milist) t1 t2 )
    | _ -> raise (SubError("Lists must be of equal lengths",None))

and member_in_modules mn modules = 
  match modules with
    | [] -> false
    | Module (_,(_,(_,name,_)),_,_) ::t -> 
        if (name=mn) then true else (member_in_modules mn t)

and modsub_modpa m1 m2 mpa = 
  match mpa with
    ModParamAssign((_,(_,nm,sub)),mpas,pas) -> 
      let mpas1 = List.map (modsub_modpa m1 m2) mpas in
	if (nm=m1) then ModParamAssign((None,(None,m2,sub)),mpas1,pas) 
	else ModParamAssign((None,(None,m1,sub)),mpas1,pas)
      
and modsub_mitem (m1:string) (m2:string) (item:module_item) : module_item = 
  match item with
    | Instantiation(_,(_,(_,mname,isSub)),mpas,pas,portcons,sigma) -> 
	let mpas1 = List.map (modsub_modpa m1 m2) mpas in
	  if (mname = m1) then Instantiation(None,(None,(None,m2,isSub)),mpas1,pas,portcons,sigma) 
	  else Instantiation(None,(None,(None,mname,isSub)),mpas1,pas,portcons,sigma)
    | P_if_stmt(_,e,mil) -> 
	let mil1 = List.map (modsub_mitem m1 m2) mil in
	  P_if_stmt(None,e,mil1)
    | P_if_else_stmt(_,e,mil1,mil2) ->
	let mil3 = List.map (modsub_mitem m1 m2) mil1 in
	let mil4 = List.map (modsub_mitem m1 m2) mil2 in
	  P_if_else_stmt(None,e,mil3,mil4)
    | P_for_stmt(_,al1,e,al2,mil) ->
	let mil1 = List.map (modsub_mitem m1 m2) mil in
	  P_for_stmt(None,al1,e,al2,mil1)
    | P_case_stmt(loc,_,_) -> raise(SubError("Unexpected: Case expressions are not supported in the currect version",loc))
    |_ -> item

and modssub_mitem (ms1:string list) (ms2:string list) (item: module_item) : module_item = 
  match (ms1,ms2) with
    | ([],[]) -> item
    | (h1::t1,h2::t2) -> modsub_mitem h1 h2 item
    | _ -> raise (SubError("Incorrect number of supplied modparameters",None))

and sub_ex_mitem (mn:string) orig_pnames orig_pvalues (orig_portList:name_of_port list) 
    (portList:name_of_port list) (nonpitem:module_item) (pnames:string list) (pvalues:number list) 
    (modps: string list) (modpvals: string list) (ml:mod_v list) (sigma:(string * vtype) list) : (name_of_port list * module_item list * mod_v list) =
  match (pnames,pvalues) with
    | ([],[]) -> ex_mitem mn orig_pnames orig_pvalues orig_portList portList ml (modssub_mitem modps modpvals nonpitem) sigma
    | (hn::tn,hv::tv) -> sub_ex_mitem mn orig_pnames orig_pvalues orig_portList portList (sub_mitem hn hv nonpitem) tn tv modps modpvals ml (sub_sigma hn hv sigma)
    | _ -> raise (SubError("Incorrect number of supplied parameter values",None))

and sub_sigma pn pv sigma =
  List.map (fun (str,t1) -> (str,sub_vtype pn pv t1)) sigma

and sub_ex_mitems (mn: string) (orig_portList:name_of_port list) (portList:name_of_port list) (nonpitems:module_item list) (pnames:string list)  
    (pvalues:number list) (modps: string list) (modpvals: string list) (ml:mod_v list) (sigma:(string * vtype) list) 
    : (name_of_port list * module_item list * mod_v list) =
  match nonpitems with
    | [] -> (portList,[],[])
    | h::t -> 
	let (portList2,nonps1,ms1) = sub_ex_mitem mn pnames pvalues orig_portList portList h pnames pvalues modps modpvals ml sigma in
	let (portList3,nonps2,ms2) = sub_ex_mitems mn orig_portList portList2 t pnames pvalues modps modpvals ml sigma in
          (portList3,List.append nonps1 nonps2,module_append ms1 ms2)              

and module_append ml1 ml2 =
  match ml1 with
    | [] -> ml2
    | modv::t -> 
	let (Module(_,(_,(_,name,_)),_,_)) = modv in 
          if (member_in_modules name ml2) then (module_append t ml2) else List.append [modv] (module_append t ml2) 

and splitParameters (mitemList:module_item list) :(string list * number list * string list * module_item list) =
  match mitemList with
    | [] -> ([],[],[],[])
    | h::t -> let (pnames,pvalues,modps,nonpitems) = splitParameters t in
        (match h with 
           | Parameter_declaration(_,pal) -> 
	       let (ns,vals) = splitPNamesValues pal in
		 ((List.append ns pnames),(List.append vals pvalues),modps,nonpitems)
	   | Mod_param_declaration(_,(_,(_,m,_)),_) ->
	       (pnames,pvalues,m::modps,nonpitems)
	   | _ -> (pnames,pvalues,modps,(h::nonpitems)))

and splitPNamesValues (paList:param_assignment list) : (string list * number list) = 
  match paList with
    | [] -> ([],[])
    | (_,(_,nm,isSub),exp,_)::t-> 
        let (ns,vs) = splitPNamesValues t in (nm::ns,getNumFromExp exp::vs)

and getParamAssignString pa = 
  String.concat "_" (List.map (fun p -> snd(getNumFromExp (ex_exp0 p))) pa)
      
and getModParamAssignString mpa =
  String.concat "__" (List.map (fun mp -> 
				 match mp with 
				     ModParamAssign ((_,(_,nm,_)),mpas,pas) -> 
				       getNewModuleName nm mpas pas) mpa)
	
and getNewModuleName nm mpas pas =
  let str = 
    begin match mpas with
	[] -> nm
      | _ -> nm^"__"^(getModParamAssignString mpas)^"_" 
    end in
    match pas with 
	[] -> str
      | _ -> str^"_"^(getParamAssignString pas) 

and getModuleFromML mname ml =
  let (loc,(_,x,isSub1)) = mname  in  
    match ml with
      | [] -> raise(ExError("Module "^x^" not found",loc))
      | Module(_,(_,(_,y,isSub2)),portList,mitemList)::t -> 
	  if (x=y) then (portList,mitemList) else getModuleFromML mname t

and ex_range r =
  match r with 
      No_range -> No_range 
    | Range (_,e1,e2) -> Range (None,ex_exp0 e1, ex_exp0 e2)

and ex_bounds bs =
  match bs with 
      No_bounds -> No_bounds
    | Bounds (_,e1,e2,b) -> Bounds (None, ex_exp0 e1, ex_exp0 e2, ex_bounds b)

and ex_a mn pnames pvalues (_,lv,exp) = 
  Util.map2perm (fun l e -> (None,l,e)) (ex_lv mn pnames pvalues lv) (ex_exp1 mn pnames pvalues exp)

(* ex_program *)
let rec ex_program p =
  modins_env := []; 
  match p with
      Source_text(_,mtl,ml) -> Source_text(None,mtl,ex_module_list ml) 
	  
	 
and ex_module_list ml =
  match ml with
      [] -> []
    | _ -> let mm = List.nth ml ((List.length ml) - 1) in
        (ex_main_module mm ml)
	  
and ex_main_module mm ml = 
  match mm with
      Module(_,(_,(_,mname,sub)),listPort,mitemList) -> 
	let (pnames,pvalues,modps,nonpitems) = (splitParameters mitemList) in
	let (listPort2,nonpitems2,modules) = (sub_ex_mitems mname listPort listPort nonpitems pnames pvalues [] [] ml []) in
	let newModule = Module(None,(None,(None,mname,sub)),listPort2,nonpitems2) in
	  module_append modules [newModule]
;;

(*------------- Termination analysis --------------------*)

type cycle = cnode list
and cnode = CNode of string * string list * edge (*Module name, parameter names, edge to instanced cnode, edge to instanciating cnode*)

let cycle_to_string (cns:cycle): string = 
  let nnms = (List.map (fun (CNode(nm,_,_)) -> nm) cns) in
    (String.concat " -> " nnms) ^ " -> " ^ (List.hd nnms)


let graph_contains_mod (gr:graph) (nm:string) :bool = 
  List.exists (fun (Node(name,_,_)) -> name=nm) gr

let get_node_by_name (gr:graph) (nm:string) : node =
  List.find (fun (Node(name,_,_)) -> name=nm) gr

let cycle_contains_mod (cns:cycle) (nm:string) :bool = 
  List.exists (fun (CNode(name,_,_)) -> name=nm) cns

let rec find_g_cs (gr:graph) (cns:cycle): cycle list = 
 match (List.hd cns, List.nth cns ((List.length cns)-1)) with
   | CNode(cnnm,_,_),CNode(_,_,Edge(_,_,nmi)) -> 
       if (cnnm = nmi) then
	 [cns]
       else 
	 if cycle_contains_mod cns nmi then []
	 else 
	   if (graph_contains_mod gr nmi) then
	     let (Node(nnm,pl,edl)) = get_node_by_name gr nmi in
	       List.flatten(List.map (fun e -> find_g_cs gr (cns@[CNode(nnm,pl,e)])) edl)
	   else []

(* TODO: improve complexity of algorithm and make sure that the
 * same cycle is never returned (& consecutively analyzed) more than 
 * once *)
let find_graph_cycles (gr:graph) : cycle list = 
  List.flatten(List.map (fun (Node(nm,pl,edl)) -> 
			   List.flatten(List.map (fun e -> find_g_cs gr [CNode(nm,pl,e)]) edl)) gr)


let filter_cycle (cns:cycle) :cycle = 
  let rec is_supported pl cs =
    match cs with
      | Bool(_) -> false
      | Relation(_,NEQ,_) -> false
      | Relation(Variable(n),_,Literal(_))   
      | Relation(Literal(_),_,Variable(n)) -> List.mem n pl  
      | Relation(_,_,_) -> false   
      | Conj(c1,c2)  
      | Disj(c1,c2) -> (is_supported pl c1) && (is_supported pl c2)
      | Neg(_) -> raise(TermErr("Unexpected: Found negated constraint after simplifying"))
  in
    List.map (fun (CNode(nm,pl,Edge(cs,es,nmi))) -> 
		CNode(nm,pl,Edge(List.filter (is_supported pl) (List.map cnstrnt_smpl cs),es,nmi))) cns

let rec find_cnode_index acc cns cnode = 
  match cnode with
    | CNode(nm,_,_) -> 
	begin match cns with
	  | [] -> raise(TermErr("Unexpected: Node not found in cycle"))
	  | (CNode(nma,_,_))::t -> if nma = nm then acc else find_cnode_index (acc+1) t cnode
	end

let getnext cns cnode = 
  let idx = find_cnode_index 0 cns cnode in
  let nextidx = if idx+1 >= List.length cns then 0 else idx+1 in
    List.nth cns nextidx 
 
let getprev cns cnode = 
  let idx = find_cnode_index 0 cns cnode in
  let previdx = if idx-1 < 0 then (List.length cns) -1 else idx-1 in
    List.nth cns previdx 

let rec find_index acc x xs = 
  begin match xs with
    | [] -> -1
    | h::t -> if x = h then acc else find_index (acc+1) x t 
  end

let rec cnstrnt_fails pnms initial_pvs final_pvs cs allcs = 
  let rev_op op = 
    match op with
      | LT -> GT
      | GT -> LT
      | LTE -> GTE
      | GTE -> LTE
      | EQ -> EQ
      | NEQ -> NEQ
  in 
  match cs with
    | [Relation (Literal(v),op,Variable(n))] -> (cnstrnt_fails pnms initial_pvs final_pvs [Relation(Variable(n),rev_op op,Literal(v))] allcs) 
    | [Relation (Variable(n),op,Literal(_))] -> 
	let p_index = find_index 0 n pnms in
	let init = vExpToConExp (List.nth initial_pvs p_index) in
	let final = vExpToConExp (List.nth final_pvs p_index) in
	  begin match op with
	    | LT -> try_prove allcs (Relation(final,GT,init))
	    | GT -> try_prove allcs (Relation(final,LT,init))
	    | LTE -> try_prove allcs (Relation(final,GT,init))
	    | GTE -> try_prove allcs (Relation(final,LT,init)) 
	    | EQ -> try_prove allcs (Relation(final,NEQ,init))
	    | NEQ -> raise(TermErr("Unexpected: NEQ constraint"))
	  end
    | [Conj (c1, c2)] -> (cnstrnt_fails pnms initial_pvs final_pvs [c1] allcs) || 
	(cnstrnt_fails pnms initial_pvs final_pvs [c2] allcs)
    | [Disj (c1, c2)] -> (cnstrnt_fails pnms initial_pvs final_pvs [c1] allcs) && 
	(cnstrnt_fails pnms initial_pvs final_pvs [c2] allcs)
    | h::t -> List.fold_left (fun b c -> b || (cnstrnt_fails pnms initial_pvs final_pvs [c] allcs)) false cs 
    | _ -> raise(TermErr("Unexpected: constraints")) 

let rec subexp_exp x e exp=
  match exp with
    | Primary(_,p) -> subexp_primary p x e
    | Unary_exp(_,op,p) -> raise(TermErr("Unsupported: unary operator parameter expressions are not supported"))
    | Bin_exp(_,exp1,op,exp2) -> Bin_exp(None,(subexp_exp x e exp1),op,(subexp_exp x e exp2))
    | Cond_exp(_,exp1,exp2,exp3) -> Cond_exp(None,(subexp_exp x e exp1),(subexp_exp x e exp2),(subexp_exp x e exp3))
    | String_exp(loc,_)-> raise(TermErr("Unexpected: String constants are not supported"))
  
and subexp_primary pri x e =
  match pri with
    | Num_primary(_,n)-> Primary(None,Num_primary(None,n))
    | Id_primary(_,(_,vname,_),No_select)-> 
	if (x=vname) then e else Primary(None,pri) 
    | _ -> raise(TermErr("Unsupported: unsupported primary expression"))

let subexps_exp xs es exp = 
  List.fold_left2 (fun exp x e -> subexp_exp x e exp) exp xs es

let rec subexp_cnstrnt x e c = 
  match c with
  | Bool(_) -> c
  | Relation(e1,rop,e2) -> Relation(subexp_expression x e e1,rop,subexp_expression x e e2)
  | Conj(c1,c2) -> Conj(subexp_cnstrnt x e c1, subexp_cnstrnt x e c2)
  | Disj(c1,c2) -> Disj(subexp_cnstrnt x e c1, subexp_cnstrnt x e c2)
  | Neg(c1) -> Neg(subexp_cnstrnt x e c1)

and subexp_expression x e exp = 
  match exp with
    | Variable(vname) -> if (x = vname) then vExpToConExp e else exp 
    | Literal(_) -> exp
    | Op(e1,op,e2) -> Op(subexp_expression x e e1,op,subexp_expression x e e2)
    | Abs(e1) -> Abs(subexp_expression x e e1)
    | Power(e1) -> Power(subexp_expression x e e1)
    | Min(e1,e2) -> Min(subexp_expression x e e1,subexp_expression x e e2)
    | Max(e1,e2) -> Max(subexp_expression x e e1,subexp_expression x e e2)
    | Shiftr(e1,e2) -> Shiftr(subexp_expression x e e1,subexp_expression x e e2)
    | Shiftl(e1,e2) -> Shiftl(subexp_expression x e e1,subexp_expression x e e2)


let subexps_cnstrnt xs es c = 
  List.fold_left2 (fun c x e -> subexp_cnstrnt x e c) c xs es

let rec propagate_pvs pvs ignm cnode cns = 
  let (CNode(cnm,pns,(Edge(_,es,cnmi)))) = cnode in 
  let new_pvs = List.map (subexps_exp pns pvs) es in
    if cnmi = ignm then new_pvs
    else propagate_pvs new_pvs ignm (getnext cns cnode) cns

let guard_fails cns gnode = 
  let (CNode(gnm,pnms,(Edge(cs,_,_)))) = gnode in 
  let (CNode(_,_,(Edge(_,initial_pvs,_)))) = getprev cns gnode in 
  let final_pvs = propagate_pvs initial_pvs gnm gnode cns in
    cnstrnt_fails pnms initial_pvs final_pvs cs (List.map (subexps_cnstrnt pnms initial_pvs) cs)
							  
let rec analyze_cycle_foredges cns gcns = 
  match gcns with
    | [] -> raise(TermErr("Cannot prove termination of the following recursive definition:\n\t" ^ (cycle_to_string cns) ^ "\n  No instanciation guards were proven to fail"))
    | h::t -> if guard_fails cns h then () else
	analyze_cycle_foredges cns t

let analyze_cycle (cns:cycle) : unit =
  let fcns = filter_cycle cns in
    if List.exists (fun (CNode(_,pl,_)) -> List.length pl = 0) fcns then
      raise(TermErr("Cannot prove termination of cycle:\n\t" ^ (cycle_to_string cns) ^ "\n  One of the modules involved is not parameterized"))
    else let guarded_cns = (List.filter (fun (CNode(_,_,Edge(cs,_,_))) -> List.length cs <> 0) fcns) in
      if (List.length guarded_cns = 0) then
	raise(TermErr("Cannot prove termination of cycle:\n\t" ^ (cycle_to_string cns) ^ "\n  No supported instanciation guards exist"))
      else analyze_cycle_foredges cns guarded_cns 

let analyze_termination (gr:graph) : unit = 
  let cycles = find_graph_cycles gr in 
    List.iter analyze_cycle cycles

