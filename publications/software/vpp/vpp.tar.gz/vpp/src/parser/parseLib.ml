
(*******  wrapper library for parser ************)

(* parse_channel: in_channel -> Ast.source_text *)
let parse_channel inputchannel =
  let lexbuf = Lexing.from_channel inputchannel in
    try
      let ast = LParser.source_text LLexer.token lexbuf in
	Parsing.clear_parser();
	ast
    with
	ParseError.Error(_) as err -> raise err
      | _ ->  
	  let pos = {ParseError.pos_start = Lexing.lexeme_start_p lexbuf;
		     ParseError.pos_end   = Lexing.lexeme_end_p lexbuf}
	  in raise (ParseError.Error(ParseError.Other(pos)))

(* parse_string: string -> Ast.source_text *)
let parse_string str =
  let lexbuf = Lexing.from_string str in
    try 
      let ast = LParser.source_text (LLexer.token) lexbuf in
	Parsing.clear_parser();
	ast
    with
	ParseError.Error(_) as err -> raise err
      | _ ->  
	  let pos = {ParseError.pos_start = Lexing.lexeme_start_p lexbuf;
		     ParseError.pos_end   = Lexing.lexeme_end_p lexbuf}
	  in raise (ParseError.Error(ParseError.Other(pos)))

(* parse_file : string -> Ast.source_text *)
let parse_file filename =
  try
    let ic = open_in filename in
      parse_channel ic
  with
      Sys_error _ -> raise (ParseError.FileNotFound filename)

(* parse_stdin: () -> Ast.source_text *)
let parse_stdin () = parse_channel stdin
