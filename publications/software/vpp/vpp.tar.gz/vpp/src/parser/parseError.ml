
(* Parsing errors *)

(* Reporting a start position and end position of text. *)
type range = {
    pos_start: Lexing.position;
    pos_end:   Lexing.position;
}

(* Types of errors that can be raised. *)
type error =
  (* Lexing errors *)
    Unterminated_comment of Lexing.position
  | Closing_noncomment of Lexing.position
  | Unterminated_string of Lexing.position
  (* Parse errors *)
  | Unclosed of range * string * range * string
  | Other of range

(* Exceptions used to raise errors *)
exception FileNotFound of string
exception Error of error

(* This function prints lexing.positions to a string *)
let string_of_position pos = 
  (string_of_int pos.Lexing.pos_lnum) ^ ":" ^
  (string_of_int (pos.Lexing.pos_cnum - pos.Lexing.pos_bol))

let string_of_range rng = 
  "(start: " ^ (string_of_position rng.pos_start) ^ ", end:" ^
  (string_of_position rng.pos_end) ^ ")"
							
