
open Format
open Ast

(* string_of location (Ast.t) *)
let loc_to_string loc = 
  begin match loc with
    | Some loc -> "(" ^ (ParseError.string_of_position loc.loc_start) ^ "-"
		   ^ (ParseError.string_of_position loc.loc_end) ^ ")"
    | None -> ""
  end

(* pretty printing Verilog *)
(* Section 1: Source Text *)

let rec print_source_text ppf x = 
  match x with (Source_text(_,_,ml)) ->
    fprintf ppf "%a" print_mod_list ml

and  print_mod_list ppf ml = 
  List.iter (fun mod_v ->
	       fprintf ppf "@[<v 0>module%a@,endmodule@,@,@]"
		 print_mod_v mod_v) ml;
  fprintf ppf "@?"

and  print_mod_v ppf (Module(_,(_,(_,nm,_)),pl,il)) =
  fprintf ppf "@[<v 0> @[<hov 2> %s@,(%a);@] %a@]" nm
    print_port_list pl
    print_mod_item_list il

and  print_port_list ppf pl =
  match pl with
      [] -> fprintf ppf ""
    | [p] -> fprintf ppf "%a" print_name_of_port p
    | p::ps -> 
	fprintf ppf "%a,%a"
	  print_name_of_port p
	  print_port_list ps

and  print_name_of_port ppf p =
  match p with
      (_,(_,name,_)) ->fprintf ppf "%s" name

and  print_mod_item_list ppf il =
  List.iter (fun mod_item ->
	       fprintf ppf "@,%a"
		 print_mod_item mod_item) il;
  fprintf ppf ""

and  print_mod_item ppf mod_item =
  match mod_item with
      Parameter_declaration(_,lopa) ->
	fprintf ppf "@[<hov 2>parameter@ %a;@]"
          print_list_of_param_assignments lopa
    | Mod_param_declaration(_,(_,(_,nm,_)),_) -> fprintf ppf "@[parameter %s@]" nm
    | Input_declaration(_, r, lov, b) ->
	fprintf ppf "@[<hov 2>input@ %a%a%a;@]"
          print_range r
          print_list_of_variables lov
	  print_bounds b
    | Output_declaration(_, r, lov, b) ->
	fprintf ppf "@[<hov 2>output@ %a%a%a;@]"
          print_range r
          print_list_of_variables lov
	  print_bounds b
    | Inout_declaration(_, r, lov, b) ->
	fprintf ppf "@[<hov 2>inout@ %a%a%a;@]"
          print_range r
          print_list_of_variables lov
	  print_bounds b
    | Net_declaration(_, (_,nt), r, d, lov, b) ->
	fprintf ppf "@[<hov 2>%s@ %a%a%a%a;@]" nt
          print_range r
          print_delay d
          print_list_of_variables lov
	  print_bounds b
    | Var_declaration(_, n, lov, b) ->
	fprintf ppf "@[<hov 2>%s@ %a%a;@]" n
          print_list_of_variables lov
	  print_bounds b
    | Reg_declaration(_, r, lov, b) ->
	fprintf ppf "@[<hov 2>reg@ %a%a%a;@]"
          print_range r
          print_list_of_variables lov
	  print_bounds b
    | Int_declaration(_,lov, b) ->
	fprintf ppf "@[<hov 2>integer@ %a%a;@]"
          print_list_of_variables lov
	  print_bounds b
    | Genvar_declaration(_,lov) ->
	fprintf ppf "@[<hov 2>genvar@ %a;@]"
          print_list_of_variables lov
    | Continuous_assign(_, d, loa) ->
	fprintf ppf "@[<hov 2>assign@ %a%a;@]"
          print_delay d
          print_list_of_assignments loa
    | Gate_declaration(_, (_,gt), d, gi) ->
	fprintf ppf "@[<hov 2>%s@ %a%a;@]" gt
          print_delay d
          print_gate_instance_list gi
    | Instantiation(_, (_,(_,mname,_)), mps, ps, minstance,_) ->
	print_module_instantiation ppf mname mps ps minstance
    | P_if_stmt(_, e, mil) ->
	fprintf ppf "@[<v 2>if (%a)@ @[%a@]@]"
          print_exp e
          print_module_item_list mil
    | P_if_else_stmt(_, e1, mil1, mil2) ->
	fprintf ppf "@[<v 0>@[<v 2>if (%a)@ @[%a@]@]@,@[<v 2>else@ @[%a@]@]@]"
          print_exp e1
          print_module_item_list mil1
          print_module_item_list mil2
    | P_for_stmt(_, loa1,b,loa2,d)-> 
	fprintf ppf "@[<v 0>@[<v 2>for (%a;%a;%a)@ @[%a@]@]@]"
	  print_list_of_assignments loa1
	  print_exp b
	  print_list_of_assignments loa2
	  print_module_item_list d
    | P_case_stmt(_,a,b)->
	fprintf ppf "@[<v 0>@[<v 2>case (%a)%a@]@,endcase@]"
	  print_exp a
	  print_p_case_item_list b
    | Always_statement(_,s) ->
	fprintf ppf "@[<v 2>always@ %a@]"
          print_statement s

and  print_module_item_list ppf mil =
  match mil with
      [] -> fprintf ppf ""
    | mi :: tl->
	fprintf ppf "@,%a%a"
	  print_mod_item mi
	  print_module_item_list tl

and print_p_case_item_list ppf cl = 
  match cl with 
      [] -> fprintf ppf ""
    | c :: tl ->
	fprintf ppf "@,%a%a"
	  print_p_case_item c
	  print_p_case_item_list tl 

and print_p_case_item ppf c =
  match c with
      P_case_item(_,exps, s) ->
	fprintf ppf "@[<v 0>%a %s %a@]"
	  print_exp_list exps ":"
	  print_module_item_list s
    | P_case_default(_,s) ->
	fprintf ppf "@[<v 0>%s %a@]"
	  "default : "
	  print_module_item_list s


(* Section 2: Declarations *)
and  print_list_of_param_assignments ppf lop =
  match lop with
      [] -> fprintf ppf ""
    | [p] -> fprintf ppf "%a" print_param_assignment p
    | p::ps -> 
	fprintf ppf "%a,@ %a"
	  print_param_assignment p
	  print_list_of_param_assignments ps

and  print_param_assignment ppf (_, (_,nm,_), e1, e2) =
  match e2 with
      None -> 
	fprintf ppf "@[<hov 2>%s@ = %a@]" nm 
	  print_exp e1
    | Some e3 -> 
	fprintf ppf "@[<hov 2>%s@ = %a where %a@]" nm 
	  print_exp e1
	  print_exp e3
	  
and  print_list_of_variables ppf lov =
  match lov with
      [] -> fprintf ppf ""
    | [v] -> fprintf ppf "%a" print_name_of_variable v
    | v::vs ->
	fprintf ppf "%a,@ %a"
	  print_name_of_variable v
	  print_list_of_variables vs

and  print_name_of_variable ppf (_,(_,nm,_)) =
  fprintf ppf "%s" nm

and  print_range ppf r =
  match r with
      No_range ->  fprintf ppf ""
    | Range(_, h, l) ->
        fprintf ppf "@[<hov 2>[%a :@ %a]@ @]"
	  print_exp h
          print_exp l

and  print_bounds ppf bs =
  match bs with
      No_bounds ->  fprintf ppf ""
    | Bounds(_, h, l, b) ->
        fprintf ppf "@[<hov 2>[%a :@ %a]@ %a  @]"
	  print_exp h
          print_exp l
	  print_bounds b

and  print_list_of_assignments ppf loa =
  match loa with
      [] -> fprintf ppf ""
    | [a] -> fprintf ppf "%a" print_assignment a
    | a::tl -> 
	fprintf ppf "%a,@ %a"
	  print_assignment a
	  print_list_of_assignments tl

(* Section 3: Primitive Instances *)
and  print_delay ppf d =
  match d with
      No_delay -> fprintf ppf ""
    | Num_delay(_,(_,n)) ->
	fprintf ppf "@[<hov 2>#%s@ @]" n
    | Ident_delay(_,i) ->
	match i with
	    (_,name,isSub) -> fprintf ppf "@[<hov 2>#%s@ @]" name

and  print_gate_instance_list ppf gil =
  match gil with
      [] -> fprintf ppf ""
    | [gi] -> fprintf ppf "%a" print_gate_instance gi
    | h :: tl ->
	fprintf ppf "%a,@ %a"
	  print_gate_instance h
	  print_gate_instance_list tl

and  print_gate_instance ppf (_, gn, lot) =
  fprintf ppf "@[<hov 2>%a(%a)@]"
    print_name_of_gate_instance gn
    print_list_of_terminals lot

and  print_name_of_gate_instance ppf nm =
  match nm with
      No_gatename  -> fprintf ppf ""
    | Gatename(_, i, r) ->
	match i with
	    (_, name,isSub) ->
	      fprintf ppf "@[<hov 2>%s@ %a@]" name
		print_range r;

and  print_list_of_terminals ppf lot =
  match lot with
      [] -> fprintf ppf ""
    | [t] -> fprintf ppf "%a" print_exp t
    | t :: tl ->
	fprintf ppf "%a,@ %a"
	  print_exp t
	  print_list_of_terminals tl

(* Section 4: Module Instantiations *)
and print_module_instantiation ppf name modparams params (_,ins_name,conlst) = 
  let print_helper fnc ppf l =
    List.iter (fun x -> fprintf ppf ",%a" fnc x) l in
  let print_params ppf params =
    match params with 
	[] -> ()
      | x :: xs -> fprintf ppf "#@[<hv 1>(%a%a)@]@;<1 0>" 
          print_exp x 
	    (print_helper print_exp) xs in  
  let rec print_modparams ppf modparams =
    match modparams with 
	[] -> ()
      | x :: xs -> fprintf ppf "##@[<hv 1>(%a%a)@]@;<1 0>" 
          print_modparam x 
	    (print_helper print_modparam) xs    
  and print_modparam ppf param = 
    match param with
	ModParamAssign ((_,(_,nm,_)),mpa,pa) -> fprintf ppf "%s %a %a"
	  nm
	  print_modparams mpa
	  print_params pa in
  let print_conlst ppf conlst = 
    match conlst with 
      |Mod_port_conn(explist) ->   
	 (match explist with
	    | [] -> ()
	    | x :: xs ->
		fprintf ppf "(%a%a)" 
		  print_exp_option x
		  (print_helper print_exp_option) xs) 
      |Named_port_conn(nconlist) ->
	 (match nconlist with
	    | [] -> ()
	    | x :: xs ->
		fprintf ppf "(%a%a)" 
		  print_namedexp x
		  (print_helper print_namedexp) xs) 
  in 
    match ins_name with
        (_,(_,ins_nm,ins_isSub)) -> fprintf ppf "@[<hv 1>%s %a %a %s %a;@]" 
          name 
	  print_modparams modparams
          print_params params 
          ins_nm 
          print_conlst conlst

(* No rules. *)

(* Section 5: Behavioral Statements *)
and  print_statement_option ppf son =
  match son with
      Some(s) ->
	fprintf ppf "%a" print_statement s
    | None -> fprintf ppf ";"

and  print_statement ppf s =
  match s with
      Blocking_assignment(_,ba) ->
	fprintf ppf "%a;"
	  print_blocking_assignment ba
    | Non_blocking_assignment(_,nba) ->
	fprintf ppf "%a;"
          print_non_blocking_assignment nba
    | If_stmt(_,e, son) ->
	fprintf ppf "@[<v 2>if (%a)@ @[%a@]@]"
          print_exp e
          print_statement_option son
    | If_else_stmt(_,e1, son1, son2) ->
	fprintf ppf "@[<v 0>@[<v 2>if (%a)@ @[%a@]@]@,@[<v 2>else@ @[%a@]@]@]"
          print_exp e1
          print_statement_option son1
          print_statement_option son2
    | Delay_or_event_control(_,doec, son3) ->
	fprintf ppf "@[<v 2>%a@ %a@]"
          print_delay_or_event_control doec
          print_statement_option son3
    | Sequential_block(_,los) ->
	fprintf ppf "@[<v 0>@[<v 2>begin%a@]@,end@]"
          print_statement_list los
    | System_task_enable(_,ste) ->
	fprintf ppf "%a"
          print_system_task_enable ste
    | Assign_stmt(_,a) ->
	fprintf ppf "@[<hov 2>assign@ %a;@]"
          print_assignment a
    | For_stmt(_,loa1,b,loa2,d)-> 
	fprintf ppf "@[<v 0>@[<v 2>for (%a;%a;%a)@ @[%a@]@]@]"
	  print_list_of_assignments loa1
	  print_exp b
	  print_list_of_assignments loa2
	  print_statement_option d
    | Case_stmt(_,a,b)->
	fprintf ppf "@[<v 0>@[<v 2>case (%a)%a@]@,endcase@]"
	  print_exp a
	  print_case_item_list b

and print_case_item_list ppf cl = 
  match cl with 
      [] -> fprintf ppf ""
    | c :: tl ->
	fprintf ppf "@,%a%a"
	  print_case_item c
	  print_case_item_list tl 

and print_case_item ppf c =
  match c with
      Case_item(_,exps, s) ->
	fprintf ppf "@[<v 0>%a %s %a@]"
	  print_exp_list exps ":"
	  print_statement_option s
    | Case_default(_,s) ->
	fprintf ppf "@[<v 0>%s %a@]"
	  "default : "
	  print_statement_option s

and  print_assignment ppf (_, lval, e) =
  fprintf ppf "@[<hov 2>%a@ = %a@]"
    print_lvalue lval
    print_exp e

and  print_blocking_assignment ppf ba =
  match ba with
      B_assign(_,lval, e) ->
	fprintf ppf "@[<hov 2>%a@ = %a@]"
	  print_lvalue lval
	  print_exp e
    | Control_B_assign(_,lval1, doec, e1) ->
	fprintf ppf "@[<hov 2>%a@ = %a@ %a@]"
	  print_lvalue lval1
	  print_delay_or_event_control doec
	  print_exp e1

and  print_non_blocking_assignment ppf nba =
  match nba with
      Nb_assign(_,lval, e) ->
	fprintf ppf "@[<hov 2>%a@ <= %a@]"
	  print_lvalue lval
	  print_exp e
    | Control_Nb_assign(_,lval1, doec, e1) ->
	fprintf ppf "@[<hov 2>%a@ <= %a@ %a@]"
	  print_lvalue lval1
	  print_delay_or_event_control doec
	  print_exp e1

and  print_statement_list ppf sl =
  match sl with
      [] -> fprintf ppf ""
    | s :: tl->
	fprintf ppf "@,%a%a"
	  print_statement s
	  print_statement_list tl

and  print_delay_or_event_control ppf doe =
  match doe with
      Delay_control(_,dc) ->
	fprintf ppf "%a"
	  print_delay_control dc
    | Event_control(_,ec) ->
	fprintf ppf "%a"
	  print_event_control ec

and  print_system_task_enable ppf ste =
  match ste with
      Sys_task(_,stn) ->
	fprintf ppf "%a;"
	  print_name_of_system_task stn
    | Sys_task_e(_,stn1, el) ->
	fprintf ppf "@[<hov 2>%a@ @[<hov 2>(%a);@]@]"
	  print_name_of_system_task stn1
	  print_exp_list el

and  print_name_of_system_task ppf (_,stn) =
  fprintf ppf "%s" stn

and  print_exp_list ppf el =
  match el with
      [] -> fprintf ppf ""
    | [e] -> fprintf ppf "%a" print_exp e
    | e :: tl ->
	fprintf ppf "%a,@ %a"
	  print_exp e
	  print_exp_list tl

(* Section 6: Specify Section *)
(* No rules. *)

(* Section 7: Expressions *)
and  print_lvalue ppf lv =
  match lv with
    | Ident_lval(_,id1, sel) ->
	(match id1 with (_,nm,isSub) -> fprintf ppf "@[<hov 2>%s%a@]" nm)
	  print_select sel
    | Concat_lv(_,exps) -> 	print_concat ppf exps

and  print_mintypmax_exp ppf m =
  match m with
      Exp_mtm(_,e) ->
	fprintf ppf "%a" print_exp e
    | Mintypmax(_, e1, e2, e3) ->
	fprintf ppf "@[<hov 2>%a :@ %a :@ %a@]"
          print_exp e1
          print_exp e2
          print_exp e3

and print_namedexp ppf nexp =
  match nexp with (n,exp) ->
    fprintf ppf ".%s(%a)"
      (match n with (_,nm,_) -> nm)
      print_exp_option exp

and print_exp_option ppf expon =
  match expon with
    | Some(exp) -> print_exp ppf exp
    | None  -> fprintf ppf " "

and  print_exp ppf expr =
  match expr with
      Primary(_,p) ->
	fprintf ppf "%a" print_primary p
    | Unary_exp(_,uop, operand) ->
	fprintf ppf "@[<hov 2>%s %a@]" uop print_primary operand
    | Bin_exp(_,operand1, op, operand2) ->
	fprintf ppf "@[<hov 2>(%a@ %s %a)@]"
          print_exp operand1 op print_exp operand2
    | Cond_exp(_,cond, ch1, ch2) ->
	fprintf ppf "@[<hv 2>%a ?@ %a :@ %a@]"
          print_exp cond
          print_exp ch1
          print_exp ch2
    | String_exp(_,s) ->
	fprintf ppf "\"%s\"" s

and  print_primary ppf p =
  match p with
      Num_primary(_,(_,n)) ->
	fprintf ppf "%s" n
    | Id_primary(_,ident, sel) ->
	(match ident with (_,nm,isSub) -> fprintf ppf "@[<hov 2>%s%a@]" nm print_select sel)
    | Concat(_,exps) -> 	print_concat ppf exps
    | Mult_concat(_,exp, exps) -> print_mult_concat ppf exp exps
    | Mintypmax_primary(_,m) ->
	fprintf ppf "(%a)"
          print_mintypmax_exp m

and print_select ppf s = 
  match s with
      No_select -> fprintf ppf ""
    | Bit_select(_,e,sel) -> fprintf ppf "@[<hov 2>@ [%a]%a@]" print_exp e print_select sel
    | Part_select(_,e1,e2,sel) -> fprintf ppf "@[<hov 2>@ [%a :@ %a]%a@]" print_exp e1 print_exp e2 print_select sel

and print_concat ppf exps =
  fprintf ppf "@[<hov 2>{%a}@]"
    print_exp_list exps


and print_mult_concat ppf exp exps =
  fprintf ppf "@[<hov 2>{%a@,{%a}}@]"
    print_exp exp
    print_exp_list exps



(* Section 8: General *)
and  print_delay_control ppf dc =
  match dc with
      Num_dc(_,(_,n)) ->
	fprintf ppf "@[<hov 2>#%s@]" n
    | Ident_dc(_,id) ->
	(match id with (_,nm,isSub) -> fprintf ppf "@[<hov 2>#%s@]" nm)
    | Mintypmax_dc(_,m) ->
	fprintf ppf "@[<hov 2>#(%a)@]"
	  print_mintypmax_exp m

and  print_event_control ppf ec =
  match ec with
      Id_ec(_,id) ->
	(match id with (_,nm,isSub) -> fprintf ppf "@[<hov 2>@@%s@]" nm)
    | Event_exp(_,ee) ->
	fprintf ppf "@[<hov 2>@@(%a)@]"
	  print_event_exp ee

and  print_event_exp ppf ee =
  match ee with
      Exp_event(_,e) ->
	fprintf ppf "%a"
	  print_exp e
    | Posedge(_,se1) ->
	fprintf ppf "@[<hov 2>posedge@ %a@]"
	  print_scalar_event_exp se1
    | Negedge(_,se2) ->
	fprintf ppf "@[<hov 2>negedge@ %a@]"
	  print_scalar_event_exp se2
    | Or_event_exp(_, ee1, ee2) ->
	fprintf ppf "@[<hov 2>%a@ or %a@]"
	  print_event_exp ee1
	  print_event_exp ee2

and  print_scalar_event_exp ppf (_,se) =
  fprintf ppf "%a"
    print_exp se

(*and  print_prog_string size source_text =
  ignore (flush_str_formatter ());
  pp_set_margin str_formatter size;
  print_source_text str_formatter source_text;
  flush_str_formatter ()*)

(*--- pretty printing Verilog Constraints ---*)

let rec print_mod_constrnts_list ppf cl =
  List.iter (fun (mname,slst) ->
	       fprintf ppf "@[<v 0>Constraints for module %s:@,%a@,@,@]" mname print_sat_lst slst) cl

and print_sat_lst ppf slst = 
  List.iter (fun (cns,c,sat) -> 
	       fprintf ppf "@[<v 0>Given:@,%a@]"
		 print_constrnt_list cns; 
	       fprintf ppf "@[<v 0>Show that:@,%a@,@]" 
		 print_constrnt c;
	       fprintf ppf "@[<v 0>Result:@,%a@,@,@]" 
		 print_sat_result sat) slst

and print_sat_result ppf r = 
  match !r with
    |None -> fprintf ppf "unknown"
    |Some b -> fprintf ppf "%a" pp_print_bool b


and print_constrnt_list ppf cl =  
  List.iter (fun constrnt ->
	       fprintf ppf "@[<v 0>%a@,@]"
		 print_constrnt constrnt) cl;
  
and  print_constrnt ppf constrnt=
  match constrnt with
    Bool(true) -> fprintf ppf "@[true@]"
  | Bool(false) -> fprintf ppf "@[false@]"
  | Relation(e1,rop,e2) -> fprintf ppf "@[(%a@ %a %a)@]"
	print_rel_op rop
	print_expression e1
	print_expression e2
  | Conj(c1,c2) -> fprintf ppf "@[(and@ %a %a)@]"
	print_constrnt c1
	print_constrnt c2
  | Disj(c1,c2) -> fprintf ppf "@[(or@ %a %a)@]"
	print_constrnt c1
	print_constrnt c2
  | Neg(c) -> fprintf ppf "@[(not@ %a)@]"
	print_constrnt c

and print_expression ppf exp =
  match exp with 
  | Variable(s) -> fprintf ppf "@[%s@]" s
  | Literal(n) -> fprintf ppf "@[%d@]" n
  | Op(e1,bop,e2) -> fprintf ppf "@[(%a@ %a %a)@]"
	print_bin_op bop
	print_expression e1
	print_expression e2 
  | Abs(e) -> fprintf ppf "@[(abs@ %a)@]"
	print_expression e
  | Power(e) ->fprintf ppf "@[(pow@ %a)@]"
	print_expression e
  | Min(e1,e2) -> fprintf ppf "@[(min@ %a %a)@]"
	print_expression e1
	print_expression e2	
  | Max(e1,e2) -> fprintf ppf "@[(max@ %a %a)@]"
	print_expression e1
	print_expression e2	
  | Shiftr(e1,e2) -> fprintf ppf "@[(shiftr@ %a %a)@]"
	print_expression e1
	print_expression e2	
  | Shiftl(e1,e2) -> fprintf ppf "@[(shiftl@ %a %a)@]"
	print_expression e1
	print_expression e2	

and print_rel_op ppf op = 
  match op with
    LT -> fprintf ppf "<"
  | GT -> fprintf ppf ">"
  | LTE -> fprintf ppf "<="
  | GTE -> fprintf ppf ">="
  | EQ -> fprintf ppf "="
  | NEQ -> fprintf ppf "/="

and print_bin_op ppf op = 
  match op with
    PLUS -> fprintf ppf "+"
  | MINUS -> fprintf ppf "-"
  | TIMES -> fprintf ppf "*"
  | DIV -> fprintf ppf "/"
  | MOD-> fprintf ppf "mod"

and  print_prog_constrnts size constrnt_list =
  ignore (flush_str_formatter ());
  pp_set_margin str_formatter size;
  print_mod_constrnts_list str_formatter constrnt_list;
  flush_str_formatter ();;

let constrnt_tostring c = 
  ignore (flush_str_formatter ());
  pp_set_margin str_formatter 100000;
  print_constrnt str_formatter c;
  flush_str_formatter ();;


(*----- Gate Count AST printer -----*)

let rec print_mod_gcexp_list ppf gcl =
  List.iter (fun (mname,gcexp) ->
	       fprintf ppf "@[<v 0>Gate Count for module %s:@,%a@,@,@]" mname print_gcexp gcexp) gcl

and print_gcexp ppf gcexp =
  match gcexp with 
    | GcLit(n) -> fprintf ppf "@[%d@]" n
    | GcVar(s) -> fprintf ppf "@[%s@]" s
    | GcMod(s,es) -> fprintf ppf "@[%s(%a)@]" s print_gcexplist es	
    | GcOp(op,es) -> 
	begin match (op,es) with
	  | (uop,[e]) -> 
	      fprintf ppf "@[(%s %a)@]"
		uop
		print_gcexp e
	  | (bop,[e1;e2]) -> 
	      fprintf ppf "@[(%a %s %a)@]"
		print_gcexp e1
		bop
		print_gcexp e2
	  | ("?",[e1;e2;e3]) -> 
	      fprintf  ppf "@[(%a?%a:%a)@]"
		print_gcexp e1
		print_gcexp e2
		print_gcexp e3
	  | _ -> fprintf ppf "@[(%s %a)@]" op print_gcexplist es
	end
    | GcCond(e1,e2,e3) -> 
	fprintf  ppf "@[(%a?%a:%a)@]"
	  print_gcexp e1
	  print_gcexp e2
	  print_gcexp e3
    | GcSum(index,st,en,e) -> 
	fprintf ppf "@[(Summation of %a for %s from %a to %a)@]" 
	  print_gcexp e
	  index
	  print_gcexp st
	  print_gcexp en

and print_gcexplist ppf es = 
  List.iter (fun gcexp -> fprintf ppf "@[%a@]"  print_gcexp gcexp) es
	
and  print_prog_gcexps size gcexp_list =
  ignore (flush_str_formatter ());
  pp_set_margin str_formatter size;
  print_mod_gcexp_list str_formatter gcexp_list;
  flush_str_formatter ();;

let gcexp_tostring c = 
  ignore (flush_str_formatter ());
  pp_set_margin str_formatter 100000;
  print_gcexp str_formatter c;
  flush_str_formatter ();;
 
(* ---- Type printer ------ *)

let btype_to_string btyp = 
  match btyp with
    | WIRE -> "WIRE"
    | REG -> "REG"
    
let rec vtype_to_string typ =
  match typ with
    | INT -> "INT"
    | BTYPE(btyp) -> btype_to_string btyp
    | TVAR(s) -> s
    | VECT(btyp,None,w) ->"VECT(" ^ (btype_to_string btyp) ^ ",None," ^ (exp_to_string w) ^")"
    | VECT(btyp,Some(e1,e2),w) ->"VECT(" ^ (btype_to_string btyp) ^ ",Some(" ^ (exp_to_string e1) ^ "," ^ (exp_to_string e2) ^ ")," ^ (exp_to_string w) ^")"
    | ARR(typ,None,w) ->"ARR(" ^ (vtype_to_string typ) ^ ",None," ^ (exp_to_string w) ^")"
    | ARR(typ,Some(e1,e2),w) ->"ARR(" ^ (vtype_to_string typ) ^ ",Some(" ^ (exp_to_string e1) ^ "," ^ (exp_to_string e2) ^ ")," ^ (exp_to_string w) ^")"

and exp_to_string exp = 
  (print_expression Format.str_formatter exp;flush_str_formatter())

(*--- environement printer ---*)
let bool_to_string b = 
  if b then "true" else "false"

let dir_to_string d = 
  match d with
    | IN -> "IN" 
    | OUT -> "OUT"
    | INOUT -> "INOUT" 
    | NODIR -> "NODIR"

let env_to_string env =
  let strs = List.map (fun ((vn,isSub),dir,vtp,l) -> 
			 ("(("^vn^","^(bool_to_string !isSub)^"),"^
			    (dir_to_string dir)^","^
			    (vtype_to_string vtp)^","^
			    string_of_int l^")") ) env in
    ("Env:\n\t" ^ String.concat "\n\t" strs ^ "\n\n")
